const HALF_LIFE_MS = 30 * 24 * 60 * 60 * 1000;

const K8S_WEIGHTS = {
  crashloopbackoff: 3.0, oomkilled: 3.0, imagepullbackoff: 3.0, errimagepull: 3.0,
  pending: 2.5, evicted: 2.5, unschedulable: 2.5, terminating: 2.0,
  timeout: 2.0, refused: 2.0, forbidden: 2.0, unauthorized: 2.0,
  backoff: 1.8, throttle: 1.8, ratelimit: 1.8,
  memory: 1.5, cpu: 1.5, resource: 1.5, limit: 1.5, request: 1.5,
  liveness: 1.5, readiness: 1.5, probe: 1.5,
  image: 1.4, pull: 1.4, registry: 1.4, tag: 1.4,
  node: 1.3, notready: 1.3, drain: 1.3,
  service: 1.2, ingress: 1.2, endpoint: 1.2,
  config: 1.2, configmap: 1.2, secret: 1.2, env: 1.2,
  deploy: 1.1, deployment: 1.1, pod: 1.0, container: 1.0,
};

export function weightedTokenize(text) {
  const s      = text.toLowerCase().replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
  const words  = s.split(" ").filter(function(w) { return w.length > 1; });
  const result = {};
  for (const w of words) {
    const weight = K8S_WEIGHTS[w] || 1.0;
    result[w] = (result[w] || 0) + weight;
    if (w.length >= 4) {
      const bi = w.slice(0, 4);
      result[bi] = (result[bi] || 0) + weight * 0.5;
    }
  }
  const pairs = [];
  for (let i = 0; i < words.length - 1; i++) {
    const pair = words[i] + "_" + words[i + 1];
    const w1   = K8S_WEIGHTS[words[i]]     || 1.0;
    const w2   = K8S_WEIGHTS[words[i + 1]] || 1.0;
    result[pair] = (result[pair] || 0) + Math.max(w1, w2) * 1.2;
  }
  return result;
}

function magnitude(vec) {
  let sum = 0;
  for (const v of Object.values(vec)) sum += v * v;
  return Math.sqrt(sum) + 1e-10;
}

export function weightedCosineSim(a, b) {
  const keysA = Object.keys(a), keysB = new Set(Object.keys(b));
  let dot = 0;
  for (const k of keysA) { if (keysB.has(k)) dot += a[k] * b[k]; }
  return dot / (magnitude(a) * magnitude(b));
}

export function jaccardSim(textA, textB) {
  const setA = new Set(textA.toLowerCase().split(/[^a-z0-9]+/).filter(function(w) { return w.length > 2; }));
  const setB = new Set(textB.toLowerCase().split(/[^a-z0-9]+/).filter(function(w) { return w.length > 2; }));
  if (!setA.size && !setB.size) return 1.0;
  if (!setA.size || !setB.size) return 0.0;
  let inter = 0;
  for (const w of setA) { if (setB.has(w)) inter++; }
  return inter / (setA.size + setB.size - inter);
}

export function combinedSim(queryKey, candidateKey) {
  const vecA = weightedTokenize(queryKey);
  const vecB = weightedTokenize(candidateKey);
  const cos  = weightedCosineSim(vecA, vecB);
  const jac  = jaccardSim(queryKey, candidateKey);
  return cos * 0.65 + jac * 0.35;
}

export function computeScore(sol) {
  const age   = Date.now() - (sol.lastUsed || Date.now());
  const decay = Math.exp(-0.693 * age / HALF_LIFE_MS);
  const total = sol.successCount + sol.failCount + 1;
  const raw   = sol.successCount / total;
  const boost = Math.log1p(sol.successCount + sol.failCount) * 0.05;
  const recency = sol.successCount > 0 ? Math.min(sol.successCount / 10, 0.1) : 0;
  return Math.min(raw * decay + raw * (1 - decay) * 0.3 + boost + recency, 1.0);
}

export function rankSuggestions(collected) {
  return collected
    .map(function(s) {
      return Object.assign({}, s, { finalScore: computeScore(s) * (s.similarity || 1.0) });
    })
    .sort(function(a, b) { return b.finalScore - a.finalScore; })
    .slice(0, 6);
}
