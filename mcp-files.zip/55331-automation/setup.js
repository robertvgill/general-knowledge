#!/usr/bin/env node

import fs   from "fs/promises";
import path from "path";
import os   from "os";
import { fileURLToPath } from "url";

const __dirname  = path.dirname(fileURLToPath(import.meta.url));
const SERVER_JS  = path.join(__dirname, "server.js");
const HOME       = os.homedir();
const PLATFORM   = os.platform();

const MCP_ENTRY = {
  "55331-automation": {
    type:    "stdio",
    command: "node",
    args:    [SERVER_JS]
  }
};

const VSCODE_MCP_PATHS = PLATFORM === "win32"
  ? [path.join(HOME, "AppData", "Roaming", "Code", "User", "mcp.json")]
  : [
      path.join(HOME, "Library", "Application Support", "Code", "User", "mcp.json"),
      path.join(HOME, ".config", "Code", "User", "mcp.json")
    ];

async function findIntelliJMcpPaths() {
  const paths = [];
  let base;
  if (PLATFORM === "win32")  base = path.join(HOME, "AppData", "Roaming", "JetBrains");
  else if (PLATFORM === "darwin") base = path.join(HOME, "Library", "Application Support", "JetBrains");
  else base = path.join(HOME, ".config", "JetBrains");

  try {
    const entries = await fs.readdir(base);
    for (const e of entries) {
      if (/^IntelliJIdea|^WebStorm|^PyCharm|^GoLand|^Rider/.test(e)) {
        paths.push(path.join(base, e, "mcp.json"));
      }
    }
  } catch (e) {}
  return paths;
}

async function upsertMcpJson(filePath, entry) {
  let existing = {};
  try {
    existing = JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (e) {}

  if (!existing.servers) existing.servers = {};
  Object.assign(existing.servers, entry);

  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(existing, null, 2));
  return filePath;
}

async function main() {
  console.log("55331-automation setup");
  console.log("Platform: " + PLATFORM);
  console.log("Server:   " + SERVER_JS);
  console.log("");

  const updated = [];
  const failed  = [];

  for (const p of VSCODE_MCP_PATHS) {
    try {
      await upsertMcpJson(p, MCP_ENTRY);
      updated.push("VS Code: " + p);
    } catch (e) {
      failed.push("VS Code: " + p + " (" + e.message + ")");
    }
  }

  const ijPaths = await findIntelliJMcpPaths();
  if (ijPaths.length) {
    for (const p of ijPaths) {
      try {
        await upsertMcpJson(p, MCP_ENTRY);
        updated.push("IntelliJ: " + p);
      } catch (e) {
        failed.push("IntelliJ: " + p + " (" + e.message + ")");
      }
    }
  } else {
    console.log("No IntelliJ installations found at:");
    if (PLATFORM === "win32")       console.log("  %APPDATA%\\JetBrains\\IntelliJIdea*\\mcp.json");
    else if (PLATFORM === "darwin") console.log("  ~/Library/Application Support/JetBrains/IntelliJIdea*/mcp.json");
    else                            console.log("  ~/.config/JetBrains/IntelliJIdea*/mcp.json");
    console.log("Install IntelliJ then re-run this script.");
    console.log("");
    console.log("Manual IntelliJ config to add to mcp.json:");
    console.log(JSON.stringify({ servers: MCP_ENTRY }, null, 2));
    console.log("");
  }

  if (updated.length) {
    console.log("Updated:");
    for (const u of updated) console.log("  " + u);
  }
  if (failed.length) {
    console.log("Failed:");
    for (const f of failed) console.log("  " + f);
  }

  console.log("");
  console.log("Done. Restart your IDE(s) to pick up the new MCP server.");
}

main().catch(function(e) { console.error(e.message); process.exit(1); });
