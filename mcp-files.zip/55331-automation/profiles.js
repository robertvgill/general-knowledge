import * as k8s from "@kubernetes/client-node";
import fs        from "fs/promises";
import { PROFILES_FILE, DEFAULT_PROFILES } from "./config.js";

let PROFILES = [];
const CLIENT_CACHE = {};

export async function loadProfiles() {
  try {
    const raw    = await fs.readFile(PROFILES_FILE, "utf8");
    const parsed = JSON.parse(raw);
    PROFILES     = parsed.profiles || parsed;
  } catch (e) {
    PROFILES = DEFAULT_PROFILES;
  }
}

export function getProfiles() { return PROFILES; }

export function getProfileForNamespace(namespace) {
  const s = namespace.toLowerCase();
  for (const p of PROFILES) {
    if (new RegExp(p.namespacePattern).test(s)) return p;
  }
  return PROFILES.find(function(p) { return p.cluster === "openshift"; }) || PROFILES[0];
}

export function expandPath(p) {
  return p.replace(/%([^%]+)%/g, function(_, k) { return process.env[k] || _; });
}

export function getK8sClients(profile) {
  if (CLIENT_CACHE[profile.name]) return CLIENT_CACHE[profile.name];

  const kc = new k8s.KubeConfig();
  kc.loadFromFile(expandPath(profile.kubeconfig));
  if (profile.context) {
    try { kc.setCurrentContext(profile.context); } catch (e) {}
  }

  const clients = {
    core:    kc.makeApiClient(k8s.CoreV1Api),
    apps:    kc.makeApiClient(k8s.AppsV1Api),
    batch:   kc.makeApiClient(k8s.BatchV1Api),
    rbac:    kc.makeApiClient(k8s.RbacAuthorizationV1Api),
    net:     kc.makeApiClient(k8s.NetworkingV1Api),
    custom:  kc.makeApiClient(k8s.CustomObjectsApi),
    metrics: kc.makeApiClient(k8s.Metrics),
    storage: kc.makeApiClient(k8s.StorageV1Api),
    kc:      kc,
  };

  CLIENT_CACHE[profile.name] = clients;
  return clients;
}

export function invalidateClientCache(profileName) {
  delete CLIENT_CACHE[profileName];
}

export async function k8sCall(fn) {
  try {
    const result = await fn();
    return { success: true, data: result.body !== undefined ? result.body : result };
  } catch (err) {
    const msg = (err.body && err.body.message) || err.message || String(err);
    return { success: false, data: null, output: msg };
  }
}
