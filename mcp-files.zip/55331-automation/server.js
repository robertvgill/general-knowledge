#!/usr/bin/env node

import { Server }               from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

import { MAX_CONCURRENCY }                           from "./config.js";
import { loadProfiles, getK8sClients,
         k8sCall, expandPath, invalidateClientCache } from "./profiles.js";
import { resolveNamespace, assertRoutingIsValid }    from "./routing.js";
import { parallelMap }                               from "./concurrency.js";
import { KnowledgeBase, loadLLMCache,
         analyzeWithLLM, watchResolution,
         activeWatchers }                            from "./knowledge.js";
import { fmtPods, fmtEvents, fmtNodes, fmtDeployments,
         fmtServices, fmtConfigMaps, fmtSecrets,
         fmtPVCs, fmtNamespaces, fmtIngresses,
         fmtJobs, fmtCronJobs, fmtStatefulSets,
         fmtDaemonSets }                             from "./formatters.js";
import { TOOL_DEFINITIONS }                          from "./tools/registry.js";
import { genericList }                               from "./tools/generic.js";
import { handleRemoveResourceLimits }                from "./tools/limits.js";

const kb = new KnowledgeBase();

function detectPlaybook(symptom) {
  const s = symptom.toLowerCase();
  if (s.includes("oomkill") || s.includes("out of memory"))                               return "oomkilled";
  if (s.includes("crashloop") || s.includes("crash"))                                      return "pod_crashloop";
  if (s.includes("pending"))                                                                return "pod_pending";
  if (s.includes("imagepull") || s.includes("errimagepull"))                               return "pod_imagepull";
  if (s.includes("notready")  || s.includes("not ready"))                                  return "node_notready";
  if (s.includes("service")   || s.includes("unreachable") || s.includes("connection refused")) return "service_unreachable";
  return "general";
}

async function runDiagnostic(profile, ns, name, playbook) {
  const clients = getK8sClients(profile);
  const results = [];
  const tasks   = [];

  if (["pod_crashloop","pod_pending","pod_imagepull","oomkilled"].includes(playbook) && name) {
    tasks.push(k8sCall(function() { return clients.core.readNamespacedPod({ name: name, namespace: ns }); }).then(function(r) { results.push({ command: "get pod " + name, output: r.success ? JSON.stringify((r.data && r.data.spec) || {}, null, 2).slice(0, 600) : r.output }); }));
    tasks.push(k8sCall(function() { return clients.core.readNamespacedPodLog({ name: name, namespace: ns, tailLines: 100, previous: true }); }).then(function(r) { results.push({ command: "logs " + name + " --previous", output: r.success ? String(r.data).slice(0, 600) : r.output }); }));
    tasks.push(k8sCall(function() { return clients.core.readNamespacedPodLog({ name: name, namespace: ns, tailLines: 50 }); }).then(function(r) { results.push({ command: "logs " + name, output: r.success ? String(r.data).slice(0, 600) : r.output }); }));
  }
  if (["pod_pending","general","pod_crashloop","oomkilled","pod_imagepull"].includes(playbook))
    tasks.push(k8sCall(function() { return clients.core.listNamespacedEvent({ namespace: ns }); }).then(function(r) { results.push({ command: "events -n " + ns, output: r.success ? fmtEvents(r.data) : r.output }); }));
  if (playbook === "pod_pending") {
    tasks.push(k8sCall(function() { return clients.core.listNode({}); }).then(function(r) { results.push({ command: "get nodes", output: r.success ? fmtNodes(r.data) : r.output }); }));
    tasks.push(k8sCall(function() { return clients.core.listNamespacedPersistentVolumeClaim({ namespace: ns }); }).then(function(r) { results.push({ command: "get pvc", output: r.success ? fmtPVCs(r.data) : r.output }); }));
  }
  if (playbook === "node_notready")
    tasks.push(k8sCall(function() { return clients.core.listNode({}); }).then(function(r) { results.push({ command: "get nodes", output: r.success ? fmtNodes(r.data) : r.output }); }));
  if (playbook === "service_unreachable") {
    tasks.push(k8sCall(function() { return clients.core.listNamespacedService({ namespace: ns }); }).then(function(r) { results.push({ command: "get svc", output: r.success ? fmtServices(r.data) : r.output }); }));
    tasks.push(k8sCall(function() { return clients.core.listNamespacedEndpoints({ namespace: ns }); }).then(function(r) { results.push({ command: "get endpoints", output: r.success ? (r.data && r.data.items || []).map(function(e) { return e.metadata.name; }).join("\n") : r.output }); }));
  }
  if (playbook === "general")
    tasks.push(k8sCall(function() { return clients.core.listNamespacedPod({ namespace: ns }); }).then(function(r) { results.push({ command: "get pods", output: r.success ? fmtPods(r.data) : r.output }); }));

  await Promise.all(tasks);
  return results;
}

const server = new Server(
  { name: "55331-automation", version: "5.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async function() {
  return { tools: TOOL_DEFINITIONS };
});

server.setRequestHandler(CallToolRequestSchema, async function(request) {
  const name = request.params.name;
  const args = request.params.arguments;

  try {
    const routing = args.namespace ? resolveNamespace(args.namespace) : null;
    if (routing && routing.cluster) assertRoutingIsValid(routing.resolved, routing.cluster);
    const clients = routing ? getK8sClients(routing.profile) : null;
    const ns      = routing ? routing.resolved : null;
    const ph      = { headers: { "Content-Type": "application/merge-patch+json" } };

    if (name === "k8s_resolve_namespace") {
      const r = resolveNamespace(args.namespace);
      return { content: [{ type: "text", text: "Resolved: " + r.resolved + "\nCluster: " + r.cluster + "\nProfile: " + (r.profile && r.profile.name) + (r.aliasUsed ? "\nAlias: " + r.aliasUsed : "") }] };
    }

    if (name === "k8s_pods_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedPod({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtPods(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_pods_get") {
      const r = await k8sCall(function() { return clients.core.readNamespacedPod({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? JSON.stringify(r.data, null, 2) : "Error: " + r.output }] };
    }
    if (name === "k8s_pods_logs") {
      const r = await k8sCall(function() { return clients.core.readNamespacedPodLog({ name: args.name, namespace: ns, tailLines: args.tailLines || 100, previous: args.previous || false, container: args.container }); });
      return { content: [{ type: "text", text: "Logs: " + args.name + " (" + routing.label + ")\n\n" + (r.success ? String(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_pods_delete") {
      const r = await k8sCall(function() { return clients.core.deleteNamespacedPod({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? "Deleted pod " + args.name : "Error: " + r.output }] };
    }
    if (name === "k8s_pods_exec") {
      return { content: [{ type: "text", text: "exec is not supported via REST API. Use k8s_pods_logs to inspect the pod." }] };
    }

    if (name === "k8s_deployments_list") {
      const r = await k8sCall(function() { return clients.apps.listNamespacedDeployment({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtDeployments(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_deployments_get") {
      const r = await k8sCall(function() { return clients.apps.readNamespacedDeployment({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? JSON.stringify(r.data, null, 2) : "Error: " + r.output }] };
    }
    if (name === "k8s_deployments_scale") {
      const r = await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: args.name, namespace: ns, body: { spec: { replicas: args.replicas } } }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      return { content: [{ type: "text", text: r.success ? "Scaled " + args.name + " to " + args.replicas + " replicas" : "Error: " + r.output }] };
    }
    if (name === "k8s_deployments_restart") {
      const r = await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: args.name, namespace: ns, body: { spec: { template: { metadata: { annotations: { "kubectl.kubernetes.io/restartedAt": new Date().toISOString() } } } } } }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      return { content: [{ type: "text", text: r.success ? "Restarted " + args.name : "Error: " + r.output }] };
    }

    if (name === "k8s_services_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedService({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtServices(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_services_get") {
      const r = await k8sCall(function() { return clients.core.readNamespacedService({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? JSON.stringify(r.data, null, 2) : "Error: " + r.output }] };
    }

    if (name === "k8s_configmaps_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedConfigMap({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtConfigMaps(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_configmaps_get") {
      const r = await k8sCall(function() { return clients.core.readNamespacedConfigMap({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? JSON.stringify(r.data, null, 2) : "Error: " + r.output }] };
    }

    if (name === "k8s_secrets_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedSecret({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtSecrets(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_secrets_get") {
      const r = await k8sCall(function() { return clients.core.readNamespacedSecret({ name: args.name, namespace: ns }); });
      if (!r.success) return { content: [{ type: "text", text: "Error: " + r.output }] };
      const safe = Object.assign({}, r.data);
      if (safe.data) { safe.data = {}; Object.keys(r.data.data || {}).forEach(function(k) { safe.data[k] = "[REDACTED]"; }); }
      return { content: [{ type: "text", text: JSON.stringify(safe, null, 2) }] };
    }

    if (name === "k8s_namespaces_list") {
      const r = await k8sCall(function() { return clients.core.listNamespace({}); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "\n\n" + (r.success ? fmtNamespaces(r.data) : "Error: " + r.output) }] };
    }

    if (name === "k8s_nodes_list") {
      const r = await k8sCall(function() { return clients.core.listNode({}); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "\n\n" + (r.success ? fmtNodes(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_nodes_get") {
      const r = await k8sCall(function() { return clients.core.readNode({ name: args.name }); });
      return { content: [{ type: "text", text: r.success ? JSON.stringify(r.data, null, 2) : "Error: " + r.output }] };
    }

    if (name === "k8s_events_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedEvent({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtEvents(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_pvcs_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedPersistentVolumeClaim({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtPVCs(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_ingresses_list") {
      const r = await k8sCall(function() { return clients.net.listNamespacedIngress({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtIngresses(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_statefulsets_list") {
      const r = await k8sCall(function() { return clients.apps.listNamespacedStatefulSet({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtStatefulSets(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_daemonsets_list") {
      const r = await k8sCall(function() { return clients.apps.listNamespacedDaemonSet({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtDaemonSets(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_jobs_list") {
      const r = await k8sCall(function() { return clients.batch.listNamespacedJob({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtJobs(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_cronjobs_list") {
      const r = await k8sCall(function() { return clients.batch.listNamespacedCronJob({ namespace: ns }); });
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? fmtCronJobs(r.data) : "Error: " + r.output) }] };
    }
    if (name === "k8s_resources_scale") {
      const body = { spec: { replicas: args.replicas } };
      const r = args.kind === "StatefulSet"
        ? await k8sCall(function() { return clients.apps.patchNamespacedStatefulSet({ name: args.name, namespace: ns, body: body }, undefined, undefined, undefined, undefined, undefined, undefined, ph); })
        : await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: args.name, namespace: ns, body: body }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      return { content: [{ type: "text", text: r.success ? "Scaled " + args.kind + " " + args.name + " to " + args.replicas : "Error: " + r.output }] };
    }

    if (name === "k8s_diagnose") {
      const symptom  = args.symptom, resName = args.name || "", autoWatch = args.autoWatch !== false;
      const playbook = detectPlaybook(symptom);
      const results  = await runDiagnostic(routing.profile, ns, resName, playbook);
      const combined = results.map(function(r) { return r.command + "\n" + r.output; }).join("\n\n");
      const llm      = await analyzeWithLLM(combined, symptom, routing.cluster);
      const suggs    = kb.getSuggestions(symptom);
      if (llm && llm.suggestedFix && llm.confidence > 0.6) await kb.recordOutcome(symptom, llm.suggestedFix, false, { fixCategory: llm.fixCategory, rootCause: llm.rootCause, source: "llm", cluster: routing.cluster });
      await kb.logSession({ symptom: symptom, playbook: playbook, namespace: ns, cluster: routing.cluster, commandsRun: results.length, llmUsed: !!llm });
      let watchMsg = "";
      if (autoWatch && resName) watchMsg = await watchResolution({ podName: resName, namespace: ns, profile: routing.profile, symptom: symptom, solution: (llm && llm.suggestedFix) || (suggs[0] && suggs[0].solution) || "manual fix" }, kb);
      const llmTxt  = llm ? "\nGPT-4.1: " + llm.rootCause + "\nFix: " + llm.suggestedFix + "\nConfidence: " + Math.round(llm.confidence * 100) + "% Severity: " + llm.severity : "\nGPT-4.1 unavailable.";
      const suggTxt = suggs.length ? suggs.map(function(s, i) { return (i+1) + ". " + s.solution + " (" + Math.round(s.finalScore*100) + "%)"; }).join("\n") : "No prior experience yet.";
      const diagTxt = results.map(function(r) { return "$ " + r.command + "\n" + r.output.slice(0, 500); }).join("\n\n---\n\n");
      return { content: [{ type: "text", text: "K8s Diagnosis - " + playbook.toUpperCase() + "\nCluster: " + routing.label + "  NS: " + ns + llmTxt + "\n\nPast Solutions:\n" + suggTxt + "\n\nLive Output:\n" + diagTxt + (watchMsg ? "\n\nAuto-Watcher: " + watchMsg : "") }] };
    }

    if (name === "k8s_watch") {
      const r = resolveNamespace(args.namespace);
      assertRoutingIsValid(r.resolved, r.cluster);
      const msg = await watchResolution({ podName: args.podName, namespace: r.resolved, profile: r.profile, symptom: args.symptom, solution: args.solution }, kb);
      return { content: [{ type: "text", text: "Cluster: " + r.label + "\n\n" + msg }] };
    }
    if (name === "k8s_record_outcome") {
      const r = args.namespace ? resolveNamespace(args.namespace) : { cluster: "unknown" };
      await kb.recordOutcome(args.symptom, args.solution, args.success, { source: "manual", cluster: r.cluster || "unknown" });
      return { content: [{ type: "text", text: (args.success ? "Success" : "Failure") + " recorded. Knowledge base updated." }] };
    }
    if (name === "k8s_knowledge") {
      const cluster = args.cluster || "all";
      if (args.symptom) {
        let suggs = kb.getSuggestions(args.symptom);
        if (cluster !== "all") suggs = suggs.filter(function(s) { return s.cluster === cluster; });
        if (!suggs.length) return { content: [{ type: "text", text: "No knowledge found for: " + args.symptom }] };
        return { content: [{ type: "text", text: "Knowledge: " + args.symptom + "\n\n" + suggs.map(function(s, i) { return (i+1) + ". " + s.solution + "\n   Score: " + Math.round(s.finalScore*100) + "% ok:" + s.successCount + " fail:" + s.failCount + " " + (s.cluster || "?"); }).join("\n\n") }] };
      }
      const s = kb.getStats();
      const { getProfiles } = await import("./profiles.js");
      const profiles = getProfiles();
      const rate = s.totalSuccess + s.totalFail > 0 ? Math.round(s.totalSuccess / (s.totalSuccess + s.totalFail) * 100) : 0;
      let txt = "55331-Automation v5.0 Statistics\n\nSessions: " + s.totalSessions + "\nSymptoms: " + s.totalKnowledge + "\nSuccess rate: " + rate + "%\nAuto-learned: " + s.autoLearned + "\nWatchers: " + activeWatchers.size + "\nConcurrency: " + MAX_CONCURRENCY + "\nProfiles: " + profiles.length + "\n\nProfiles:\n";
      for (const p of profiles) txt += "  " + p.name + " -> " + p.cluster + "\n";
      return { content: [{ type: "text", text: txt }] };
    }

    if (name === "resources_list") {
      const r = await genericList(clients, args.kind, ns);
      const items = r.success && r.data && r.data.items ? r.data.items : [];
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "  NS: " + ns + "  Kind: " + args.kind + "\n\n" + (r.success ? items.map(function(i) { return i.metadata && i.metadata.name; }).join("\n") || "No items." : "Error: " + r.output) }] };
    }
    if (name === "resources_get") {
      const r = await genericList(clients, args.kind, ns);
      if (!r.success) return { content: [{ type: "text", text: "Error: " + r.output }] };
      const item = (r.data && r.data.items || []).find(function(i) { return i.metadata && i.metadata.name === args.name; });
      return { content: [{ type: "text", text: item ? JSON.stringify(item, null, 2) : args.kind + " " + args.name + " not found in " + ns }] };
    }
    if (name === "resources_describe") {
      const r = await genericList(clients, args.kind, ns);
      if (!r.success) return { content: [{ type: "text", text: "Error: " + r.output }] };
      const item = (r.data && r.data.items || []).find(function(i) { return i.metadata && i.metadata.name === args.name; });
      if (!item) return { content: [{ type: "text", text: args.kind + " " + args.name + " not found." }] };
      const evR  = await k8sCall(function() { return clients.core.listNamespacedEvent({ namespace: ns }); });
      const evts = (evR.success && evR.data && evR.data.items || []).filter(function(e) { return e.involvedObject && e.involvedObject.name === args.name; });
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) + "\n\nEvents:\n" + (evts.map(function(e) { return e.type + "  " + e.reason + "  " + e.message; }).join("\n") || "No events.") }] };
    }
    if (name === "resources_delete") {
      const k = args.kind.toLowerCase();
      let r;
      if (k === "pod")          r = await k8sCall(function() { return clients.core.deleteNamespacedPod({ name: args.name, namespace: ns }); });
      else if (k === "deployment")   r = await k8sCall(function() { return clients.apps.deleteNamespacedDeployment({ name: args.name, namespace: ns }); });
      else if (k === "service")      r = await k8sCall(function() { return clients.core.deleteNamespacedService({ name: args.name, namespace: ns }); });
      else if (k === "configmap")    r = await k8sCall(function() { return clients.core.deleteNamespacedConfigMap({ name: args.name, namespace: ns }); });
      else if (k === "secret")       r = await k8sCall(function() { return clients.core.deleteNamespacedSecret({ name: args.name, namespace: ns }); });
      else if (k === "job")          r = await k8sCall(function() { return clients.batch.deleteNamespacedJob({ name: args.name, namespace: ns }); });
      else if (k === "statefulset")  r = await k8sCall(function() { return clients.apps.deleteNamespacedStatefulSet({ name: args.name, namespace: ns }); });
      else r = { success: false, output: "Delete not supported for: " + args.kind };
      return { content: [{ type: "text", text: r.success ? "Deleted " + args.kind + " " + args.name : "Error: " + r.output }] };
    }
    if (name === "resources_update") {
      const k = args.kind.toLowerCase();
      let r;
      if (k === "deployment")        r = await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: args.name, namespace: ns, body: args.patch }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else if (k === "configmap")    r = await k8sCall(function() { return clients.core.patchNamespacedConfigMap({ name: args.name, namespace: ns, body: args.patch }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else if (k === "secret")       r = await k8sCall(function() { return clients.core.patchNamespacedSecret({ name: args.name, namespace: ns, body: args.patch }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else if (k === "statefulset")  r = await k8sCall(function() { return clients.apps.patchNamespacedStatefulSet({ name: args.name, namespace: ns, body: args.patch }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else r = { success: false, output: "Update not supported for: " + args.kind };
      return { content: [{ type: "text", text: r.success ? "Updated " + args.kind + " " + args.name : "Error: " + r.output }] };
    }
    if (name === "resources_create") {
      return { content: [{ type: "text", text: "Use resources_create_or_update with a full manifest." }] };
    }
    if (name === "resources_create_or_update") {
      const m = args.manifest;
      if (!m || !m.kind || !m.apiVersion) return { content: [{ type: "text", text: "Invalid manifest: must include apiVersion, kind, metadata, spec." }] };
      const k = (m.kind || "").toLowerCase(), rname = m.metadata && m.metadata.name;
      let r;
      if (k === "deployment") { r = await k8sCall(function() { return clients.apps.createNamespacedDeployment({ namespace: ns, body: m }); }); if (!r.success) r = await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: rname, namespace: ns, body: m }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }
      else if (k === "configmap") { r = await k8sCall(function() { return clients.core.createNamespacedConfigMap({ namespace: ns, body: m }); }); if (!r.success) r = await k8sCall(function() { return clients.core.patchNamespacedConfigMap({ name: rname, namespace: ns, body: m }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }
      else if (k === "service")   { r = await k8sCall(function() { return clients.core.createNamespacedService({ namespace: ns, body: m }); });   if (!r.success) r = await k8sCall(function() { return clients.core.patchNamespacedService({ name: rname, namespace: ns, body: m }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }
      else if (k === "secret")    { r = await k8sCall(function() { return clients.core.createNamespacedSecret({ namespace: ns, body: m }); });    if (!r.success) r = await k8sCall(function() { return clients.core.patchNamespacedSecret({ name: rname, namespace: ns, body: m }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }
      else if (k === "statefulset") { r = await k8sCall(function() { return clients.apps.createNamespacedStatefulSet({ namespace: ns, body: m }); }); if (!r.success) r = await k8sCall(function() { return clients.apps.patchNamespacedStatefulSet({ name: rname, namespace: ns, body: m }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }
      else if (k === "pod") { r = await k8sCall(function() { return clients.core.createNamespacedPod({ namespace: ns, body: m }); }); }
      else return { content: [{ type: "text", text: "Unsupported kind: " + m.kind }] };
      return { content: [{ type: "text", text: r.success ? "Applied " + m.kind + " " + rname + " in " + ns : "Error: " + r.output }] };
    }

    if (name === "helm_list" || name === "helm_install" || name === "helm_upgrade" || name === "helm_uninstall") {
      const { execFile } = await import("child_process");
      const kfg = expandPath(routing.profile.kubeconfig);
      const run = function(helmArgs) {
        return new Promise(function(resolve) {
          execFile("helm", helmArgs, { env: Object.assign({}, process.env, { KUBECONFIG: kfg }) }, function(err, stdout, stderr) {
            resolve({ success: !err, output: stdout || stderr || (err && err.message) || "" });
          });
        });
      };
      if (name === "helm_list") {
        const r = await run(["list", "--namespace", ns, "--output", "table"]);
        return { content: [{ type: "text", text: "Helm Releases  Cluster: " + routing.label + "  NS: " + ns + "\n\n" + (r.success ? r.output : "Error: " + r.output) }] };
      }
      if (name === "helm_install") {
        const hArgs = ["install", args.name, args.chart, "--namespace", ns, "--create-namespace"];
        if (args.repo) hArgs.push("--repo", args.repo);
        if (args.values) { hArgs.push("--set"); hArgs.push(Object.entries(args.values).map(function(e) { return e[0] + "=" + e[1]; }).join(",")); }
        const r = await run(hArgs);
        return { content: [{ type: "text", text: r.success ? "Installed " + args.name + " in " + ns : "Error: " + r.output }] };
      }
      if (name === "helm_upgrade") {
        const hArgs = ["upgrade", args.name, args.chart, "--namespace", ns, "--install"];
        if (args.values) { hArgs.push("--set"); hArgs.push(Object.entries(args.values).map(function(e) { return e[0] + "=" + e[1]; }).join(",")); }
        const r = await run(hArgs);
        return { content: [{ type: "text", text: r.success ? "Upgraded " + args.name + " in " + ns : "Error: " + r.output }] };
      }
      if (name === "helm_uninstall") {
        const r = await run(["uninstall", args.name, "--namespace", ns]);
        return { content: [{ type: "text", text: r.success ? "Uninstalled " + args.name + " from " + ns : "Error: " + r.output }] };
      }
    }

    if (name === "pods_top") {
      const r = await k8sCall(function() { return clients.metrics.getPodMetrics(ns); });
      if (!r.success || !r.data) return { content: [{ type: "text", text: "Metrics unavailable: " + (r.output || "metrics-server not installed") }] };
      const out = (r.data.items || []).filter(function(p) { return !args.name || p.metadata.name === args.name; })
        .map(function(p) { const cpu = p.containers.reduce(function(a, c) { return a + parseInt(c.usage.cpu || "0"); }, 0); const mem = p.containers.reduce(function(a, c) { return a + parseInt(c.usage.memory || "0"); }, 0); return p.metadata.name + "  cpu:" + cpu + "m  mem:" + Math.round(mem/1024) + "Mi"; }).join("\n") || "No metrics.";
      return { content: [{ type: "text", text: "Pod Metrics  NS: " + ns + "\n\n" + out }] };
    }
    if (name === "nodes_top") {
      const r = await k8sCall(function() { return clients.metrics.getNodeMetrics(); });
      if (!r.success || !r.data) return { content: [{ type: "text", text: "Metrics unavailable: " + (r.output || "metrics-server not installed") }] };
      const out = (r.data.items || []).map(function(n) { const cpu = parseInt(n.usage.cpu || "0"); const mem = parseInt(n.usage.memory || "0"); return n.metadata.name + "  cpu:" + cpu + "m  mem:" + Math.round(mem/1024) + "Mi"; }).join("\n");
      return { content: [{ type: "text", text: "Node Metrics  Cluster: " + routing.label + "\n\n" + out }] };
    }

    if (name === "rollout_status") {
      let r;
      if (args.kind === "Deployment")       r = await k8sCall(function() { return clients.apps.readNamespacedDeployment({ name: args.name, namespace: ns }); });
      else if (args.kind === "StatefulSet") r = await k8sCall(function() { return clients.apps.readNamespacedStatefulSet({ name: args.name, namespace: ns }); });
      else                                  r = await k8sCall(function() { return clients.apps.readNamespacedDaemonSet({ name: args.name, namespace: ns }); });
      return { content: [{ type: "text", text: r.success ? args.kind + " " + args.name + " status:\n" + JSON.stringify(r.data && r.data.status, null, 2) : "Error: " + r.output }] };
    }
    if (name === "rollout_undo") {
      const body = { spec: { template: { metadata: { annotations: { "kubectl.kubernetes.io/restartedAt": new Date().toISOString() } } } } };
      let r;
      if (args.kind === "Deployment")       r = await k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: args.name, namespace: ns, body: body }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else if (args.kind === "StatefulSet") r = await k8sCall(function() { return clients.apps.patchNamespacedStatefulSet({ name: args.name, namespace: ns, body: body }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      else                                  r = await k8sCall(function() { return clients.apps.patchNamespacedDaemonSet({ name: args.name, namespace: ns, body: body }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      return { content: [{ type: "text", text: r.success ? "Restarted " + args.kind + " " + args.name : "Error: " + r.output }] };
    }

    if (name === "pods_cleanup") {
      const r = await k8sCall(function() { return clients.core.listNamespacedPod({ namespace: ns }); });
      if (!r.success) return { content: [{ type: "text", text: "Error: " + r.output }] };
      const FAILED = ["Evicted","Error","CrashLoopBackOff","Completed","OOMKilled","ContainerStatusUnknown"];
      const bad = (r.data && r.data.items || []).filter(function(p) {
        const phase = p.status && p.status.phase, reason = p.status && p.status.reason, cs = p.status && p.status.containerStatuses || [];
        return FAILED.includes(reason) || phase === "Failed" || phase === "Succeeded" || cs.some(function(c) { return c.state && c.state.waiting && FAILED.includes(c.state.waiting.reason); });
      });
      if (!bad.length) return { content: [{ type: "text", text: "No failed pods in " + ns }] };
      const deleted = [];
      await Promise.all(bad.map(function(p) { return k8sCall(function() { return clients.core.deleteNamespacedPod({ name: p.metadata.name, namespace: ns }); }).then(function(dr) { if (dr.success) deleted.push(p.metadata.name); }); }));
      return { content: [{ type: "text", text: "Deleted " + deleted.length + " failed pods:\n" + deleted.join("\n") }] };
    }

    if (name === "nodes_cordon" || name === "nodes_uncordon") {
      const r = await k8sCall(function() { return clients.core.patchNode({ name: args.name, body: { spec: { unschedulable: name === "nodes_cordon" } } }, undefined, undefined, undefined, undefined, undefined, undefined, ph); });
      return { content: [{ type: "text", text: r.success ? (name === "nodes_cordon" ? "Cordoned" : "Uncordoned") + " node " + args.name : "Error: " + r.output }] };
    }

    if (name === "nodes_stats_summary") {
      const nr = await k8sCall(function() { return clients.core.readNode({ name: args.name }); });
      if (!nr.success) return { content: [{ type: "text", text: "Error: " + nr.output }] };
      const node = nr.data, cap = node.status && node.status.capacity || {}, alloc = node.status && node.status.allocatable || {};
      const conds = (node.status && node.status.conditions || []).map(function(c) { return c.type + ":" + c.status; }).join("  ");
      return { content: [{ type: "text", text: "Node: " + args.name + "\nCluster: " + routing.label + "\nCapacity: cpu=" + cap.cpu + " memory=" + cap.memory + " pods=" + cap.pods + "\nAllocatable: cpu=" + alloc.cpu + " memory=" + alloc.memory + " pods=" + alloc.pods + "\nConditions: " + conds + "\nOS: " + (node.status && node.status.nodeInfo && node.status.nodeInfo.osImage) + "\nKernel: " + (node.status && node.status.nodeInfo && node.status.nodeInfo.kernelVersion) }] };
    }
    if (name === "nodes_log") {
      const r = await k8sCall(function() { return clients.core.readNamespacedPodLog({ name: args.name, namespace: "kube-system", tailLines: args.tailLines || 100 }); });
      return { content: [{ type: "text", text: r.success ? "Node logs " + args.name + ":\n\n" + String(r.data) : "Node logs not accessible: " + r.output }] };
    }

    if (name === "serviceaccounts_list") {
      const r = await k8sCall(function() { return clients.core.listNamespacedServiceAccount({ namespace: ns }); });
      return { content: [{ type: "text", text: "ServiceAccounts in " + ns + ":\n" + (r.success ? (r.data && r.data.items || []).map(function(s) { return s.metadata.name; }).join("\n") : "Error: " + r.output) }] };
    }
    if (name === "roles_list") {
      const r = await k8sCall(function() { return clients.rbac.listNamespacedRole({ namespace: ns }); });
      return { content: [{ type: "text", text: "Roles in " + ns + ":\n" + (r.success ? (r.data && r.data.items || []).map(function(r2) { return r2.metadata.name; }).join("\n") : "Error: " + r.output) }] };
    }
    if (name === "rolebindings_list") {
      const r = await k8sCall(function() { return clients.rbac.listNamespacedRoleBinding({ namespace: ns }); });
      return { content: [{ type: "text", text: "RoleBindings in " + ns + ":\n" + (r.success ? (r.data && r.data.items || []).map(function(rb) { return rb.metadata.name + " -> " + (rb.roleRef && rb.roleRef.name); }).join("\n") : "Error: " + r.output) }] };
    }
    if (name === "networkpolicies_list") {
      const r = await k8sCall(function() { return clients.net.listNamespacedNetworkPolicy({ namespace: ns }); });
      return { content: [{ type: "text", text: "NetworkPolicies in " + ns + ":\n" + (r.success ? (r.data && r.data.items || []).map(function(n2) { return n2.metadata.name; }).join("\n") : "Error: " + r.output) }] };
    }
    if (name === "storageclasses_list") {
      const r = await k8sCall(function() { return clients.storage.listStorageClass({}); });
      return { content: [{ type: "text", text: "StorageClasses:\n" + (r.success ? (r.data && r.data.items || []).map(function(s) { return s.metadata.name + "  provisioner:" + s.provisioner; }).join("\n") : "Error: " + r.output) }] };
    }
    if (name === "persistentvolumes_list") {
      const r = await k8sCall(function() { return clients.core.listPersistentVolume({}); });
      return { content: [{ type: "text", text: "PersistentVolumes:\n" + (r.success ? (r.data && r.data.items || []).map(function(p) { return p.metadata.name + "  " + (p.status && p.status.phase) + "  " + (p.spec && p.spec.storageClassName); }).join("\n") : "Error: " + r.output) }] };
    }

    if (name === "pods_run") {
      const pod = { apiVersion: "v1", kind: "Pod", metadata: { name: args.name, namespace: ns }, spec: { containers: [{ name: args.name, image: args.image, ports: args.port ? [{ containerPort: args.port }] : [] }], restartPolicy: "Always" } };
      const r = await k8sCall(function() { return clients.core.createNamespacedPod({ namespace: ns, body: pod }); });
      if (!r.success) return { content: [{ type: "text", text: "Error: " + r.output }] };
      let txt = "Created pod " + args.name + " with image " + args.image;
      if (args.expose && args.port) {
        const svc = { apiVersion: "v1", kind: "Service", metadata: { name: args.name, namespace: ns }, spec: { selector: { run: args.name }, ports: [{ port: args.port, targetPort: args.port }], type: "ClusterIP" } };
        const sr = await k8sCall(function() { return clients.core.createNamespacedService({ namespace: ns, body: svc }); });
        txt += sr.success ? "\nService created on port " + args.port : "\nService failed: " + sr.output;
      }
      return { content: [{ type: "text", text: txt }] };
    }

    if (name === "configuration_view") {
      const kc2 = getK8sClients(routing.profile).kc;
      const ctxs = kc2.getContexts() || [], cls = kc2.getClusters() || [], cur = kc2.getCurrentContext();
      return { content: [{ type: "text", text: "Cluster: " + routing.label + "\nCurrent: " + cur + "\n\nContexts:\n" + ctxs.map(function(c) { return (c.name === cur ? "* " : "  ") + c.name + "  cluster:" + c.cluster; }).join("\n") + "\n\nClusters:\n" + cls.map(function(c) { return "  " + c.name + "  " + c.server; }).join("\n") }] };
    }
    if (name === "configuration_use_context") {
      invalidateClientCache(routing.profile.name);
      routing.profile.context = args.context;
      return { content: [{ type: "text", text: "Switched to context " + args.context + " for profile " + routing.profile.name }] };
    }

    if (name === "remove_resource_limits") {
      return handleRemoveResourceLimits(args);
    }

    return { content: [{ type: "text", text: "Unknown tool: " + name }] };

  } catch (err) {
    return { content: [{ type: "text", text: "HARD STOP\n\n" + err.message }], isError: true };
  }
});

await loadProfiles();
await kb.load();
await loadLLMCache();

const transport = new StdioServerTransport();
await server.connect(transport);

process.on("exit",    function() { activeWatchers.forEach(function(w) { clearTimeout(w.timer); }); });
process.on("SIGINT",  function() { activeWatchers.forEach(function(w) { clearTimeout(w.timer); }); process.exit(0); });
process.on("SIGTERM", function() { activeWatchers.forEach(function(w) { clearTimeout(w.timer); }); process.exit(0); });
