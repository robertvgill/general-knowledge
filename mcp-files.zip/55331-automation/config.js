import path from "path";
import os   from "os";

export const MAX_CONCURRENCY = 100;

export const PROFILES_FILE = path.join(os.homedir(), "AppData", "Roaming", "Code", "User", ".github", "55331-automation", "profiles.json");

export const DEFAULT_PROFILES = [
  {
    name:             "openshift-prod",
    kubeconfig:       path.join(os.homedir(), "kubeconfig", "openshift-config"),
    cluster:          "openshift",
    namespacePattern: "^credit|^crm"
  },
  {
    name:             "ske-prod",
    kubeconfig:       path.join(os.homedir(), "kubeconfig", "ske-config"),
    cluster:          "ske",
    namespacePattern: "^t-55331-"
  }
];

export const DATA_DIR = path.join(os.homedir(), ".55331-automation");

function intellijConfigPath() {
  const home = os.homedir();
  const plat = os.platform();
  if (plat === "win32") return path.join(home, "AppData", "Roaming", "JetBrains");
  if (plat === "darwin") return path.join(home, "Library", "Application Support", "JetBrains");
  return path.join(home, ".config", "JetBrains");
}

export const INTELLIJ_CONFIG_BASE = intellijConfigPath();
