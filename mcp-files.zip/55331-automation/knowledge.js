import { k8sCall, getK8sClients } from "./profiles.js";
import { KnowledgeStore }         from "./storage.js";
import { combinedSim, rankSuggestions } from "./similarity.js";

function hashStr(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return (h >>> 0).toString(36);
}

let llmCache = {};
const store  = new KnowledgeStore();

export async function loadLLMCache() {
  llmCache = await store.loadLLMCache();
}

async function saveLLMCache() {
  const keys = Object.keys(llmCache);
  if (keys.length > 200) {
    const trimmed = {};
    keys.slice(-200).forEach(function(k) { trimmed[k] = llmCache[k]; });
    llmCache = trimmed;
  }
  await store.saveLLMCache(llmCache);
}

export async function analyzeWithLLM(output, symptom, clusterName) {
  const cacheKey = hashStr(symptom + output.slice(0, 500));
  if (llmCache[cacheKey]) return llmCache[cacheKey];

  const proxyUri = process.env.VSCODE_PROXY_URI || process.env.COPILOT_PROXY_URI;
  const token    = process.env.GITHUB_TOKEN || process.env.COPILOT_TOKEN || process.env.VSCODE_COPILOT_TOKEN;
  if (!proxyUri && !token) return null;

  const clusterType = clusterName === "ske" ? "Kubernetes (RHEL)" : "OpenShift";
  const prompt = "Analyze this " + clusterType + " output. Return ONLY valid JSON, no markdown.\n\n" +
    "Symptom: " + symptom + "\n" +
    "Output:\n" + output.slice(0, 3000) + "\n\n" +
    "{\n" +
    "  \"rootCause\": \"one concise sentence\",\n" +
    "  \"confidence\": 0.0,\n" +
    "  \"suggestedFix\": \"what to change in the manifest or config - no CLI commands\",\n" +
    "  \"fixCategory\": \"config|resource|image|network|secret|node|rbac|storage|helm\",\n" +
    "  \"severity\": \"critical|high|medium|low\",\n" +
    "  \"additionalChecks\": []\n" +
    "}";

  try {
    const baseUrl = proxyUri || "https://api.githubcopilot.com";
    const url     = new URL("/v1/chat/completions", baseUrl);
    const body    = JSON.stringify({ model: "gpt-4.1", max_tokens: 600, temperature: 0, messages: [{ role: "user", content: prompt }] });
    const mod     = await import(url.protocol === "https:" ? "https" : "http");
    const lib     = mod.default || mod;

    const raw = await new Promise(function(resolve, reject) {
      const req = lib.request({
        hostname: url.hostname,
        port:     url.port || (url.protocol === "https:" ? 443 : 80),
        path:     url.pathname,
        method:   "POST",
        headers: {
          "Content-Type":           "application/json",
          "Content-Length":         Buffer.byteLength(body),
          "Authorization":          "Bearer " + (token || "copilot"),
          "Copilot-Integration-Id": "vscode-chat",
          "Editor-Version":         "vscode/1.95.0"
        },
      }, function(res) { let d = ""; res.on("data", function(c) { d += c; }); res.on("end", function() { resolve(d); }); });
      req.on("error", reject); req.write(body); req.end();
    });

    const json    = JSON.parse(raw);
    const content = json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content;
    if (!content) return null;

    const fence   = String.fromCharCode(96, 96, 96);
    const cleaned = content.replace(new RegExp(fence + "json|" + fence, "g"), "").trim();
    const result  = JSON.parse(cleaned);
    llmCache[cacheKey] = result;
    await saveLLMCache();
    return result;
  } catch (e) { return null; }
}

export const activeWatchers = new Map();

export async function watchResolution(opts, kb) {
  const POLL_MS = 15000, MAX_MS = 600000, CONFIRM_N = 2;
  const start   = Date.now();
  const podKey  = opts.profile.name + "/" + opts.namespace + "/" + opts.podName;
  let consecutive = 0;
  if (activeWatchers.has(podKey)) clearTimeout(activeWatchers.get(podKey).timer);
  const check = async function() {
    if (Date.now() - start > MAX_MS) { activeWatchers.delete(podKey); return; }
    const clients = getK8sClients(opts.profile);
    const r = await k8sCall(function() { return clients.core.readNamespacedPodStatus({ name: opts.podName, namespace: opts.namespace }); });
    const phase = r.success && r.data && r.data.status ? r.data.status.phase : "Unknown";
    if (phase === "Running") {
      if (++consecutive >= CONFIRM_N) {
        await kb.recordOutcome(opts.symptom, opts.solution, true, { source: "auto", cluster: opts.profile.cluster });
        activeWatchers.delete(podKey);
        return;
      }
    } else if (phase === "Failed" || phase === "Unknown") {
      await kb.recordOutcome(opts.symptom, opts.solution, false, { source: "auto", cluster: opts.profile.cluster });
      activeWatchers.delete(podKey);
      return;
    } else { consecutive = 0; }
    const timer = setTimeout(check, POLL_MS);
    activeWatchers.set(podKey, { timer: timer });
  };
  const timer = setTimeout(check, POLL_MS);
  activeWatchers.set(podKey, { timer: timer });
  return "Watching " + podKey + " every 15s (up to 10min).";
}

function normalizeKey(s) {
  return s.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, " ").trim().slice(0, 120);
}

function extractPatterns(text) {
  const rx = /(crashloopbackoff|oomkilled|imagepullbackoff|errimagepull|pending|evicted|unschedulable|timeout|connection refused|permission denied|forbidden|backoff|throttling|readiness|liveness)/gi;
  return Array.from(new Set((text.match(rx) || []).map(function(m) { return m.toLowerCase(); })));
}

export class KnowledgeBase {
  constructor() {}

  async load() {
    await store.open();
  }

  async recordOutcome(symptom, solution, success, meta) {
    meta = meta || {};
    const key = normalizeKey(symptom);
    await store.recordOutcome(key, solution, success, meta);
    await store.recordPatterns(extractPatterns(symptom));
  }

  getSuggestions(symptom) {
    const key        = normalizeKey(symptom);
    const candidates = store.findCandidateKeys(key);
    const seen       = new Set();
    const collected  = [];

    for (const sol of store.getSolutions(key)) {
      if (!seen.has(sol.solution)) {
        seen.add(sol.solution);
        collected.push(Object.assign({}, sol, { similarity: 1.0 }));
      }
    }

    for (const candidateKey of candidates) {
      if (candidateKey === key) continue;
      const sim = combinedSim(key, candidateKey);
      if (sim < 0.25) continue;
      for (const sol of store.getSolutions(candidateKey)) {
        if (!seen.has(sol.solution)) {
          seen.add(sol.solution);
          collected.push(Object.assign({}, sol, { similarity: sim }));
        }
      }
    }

    return rankSuggestions(collected);
  }

  async logSession(s) {
    await store.recordSession(s);
  }

  getStats() {
    const knowledge = store.getKnowledge();
    const sessions  = store.getSessions();
    const patterns  = store.getPatterns();
    let totalSuccess = 0, totalFail = 0, autoLearned = 0;
    const categories = {}, clusterBreakdown = {};
    for (const sols of Object.values(knowledge)) {
      for (const s of sols) {
        totalSuccess += s.successCount;
        totalFail    += s.failCount;
        if (s.source !== "manual") autoLearned++;
        categories[s.fixCategory || "unknown"]  = (categories[s.fixCategory || "unknown"]  || 0) + 1;
        clusterBreakdown[s.cluster || "unknown"] = (clusterBreakdown[s.cluster || "unknown"] || 0) + 1;
      }
    }
    return {
      totalSessions:    sessions.length,
      totalKnowledge:   Object.keys(knowledge).length,
      totalSuccess:     totalSuccess,
      totalFail:        totalFail,
      autoLearned:      autoLearned,
      categories:       categories,
      clusterBreakdown: clusterBreakdown,
      topPatterns:      Object.entries(patterns)
        .sort(function(a, b) { return b[1] - a[1]; })
        .slice(0, 10)
        .map(function(e) { return { pattern: e[0], count: e[1] }; })
    };
  }

  async close() {
    await store.close();
  }
}
