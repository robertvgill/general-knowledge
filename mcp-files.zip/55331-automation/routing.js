import { getProfileForNamespace } from "./profiles.js";

export function resolveNamespace(raw) {
  if (!raw || !raw.trim()) return { resolved: null, cluster: null, empty: true };
  const s = raw.trim().toLowerCase();

  const crmMatch = s.match(/^crm(\d{1,2})$/);
  if (crmMatch) {
    const resolved = "creditmate-" + crmMatch[1];
    const profile  = getProfileForNamespace(resolved);
    return { resolved: resolved, cluster: profile.cluster, label: profile.name, aliasUsed: s + " -> " + resolved, profile: profile };
  }

  const profile = getProfileForNamespace(s);
  return { resolved: s, cluster: profile.cluster, label: profile.name, profile: profile };
}

export function assertRoutingIsValid(namespace, cluster) {
  if (cluster === "ske" && !/^t-55331-/.test(namespace)) {
    throw new Error("HARD STOP: namespace " + namespace + " must go to OpenShift, not SKE.");
  }
}
