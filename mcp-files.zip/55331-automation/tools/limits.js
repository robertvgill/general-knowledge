import { k8sCall } from "../profiles.js";
import { resolveNamespace } from "../routing.js";
import { pooled, parallelMap } from "../concurrency.js";

function stripResources(container, removeReqs) {
  if (!container.resources) return false;
  let changed = false;
  if (container.resources.limits) { delete container.resources.limits; changed = true; }
  if (removeReqs && container.resources.requests) { delete container.resources.requests; changed = true; }
  if (changed && Object.keys(container.resources).length === 0) delete container.resources;
  return changed;
}

function stripPodSpec(spec, removeReqs) {
  let changed = false;
  const all = [].concat(spec.containers || []).concat(spec.initContainers || []).concat(spec.ephemeralContainers || []);
  for (const c of all) { if (stripResources(c, removeReqs)) changed = true; }
  return changed;
}

async function resolveNamespaces(pattern, clients) {
  if (!pattern.includes("*") && !pattern.includes("?")) return [pattern];
  const r = await k8sCall(function() { return clients.core.listNamespace({}); });
  if (!r.success || !r.data) return [pattern];
  const rx = new RegExp("^" + pattern.replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
  return (r.data.items || []).map(function(n) { return n.metadata.name; }).filter(function(n) { return rx.test(n); });
}

async function processNamespace(nsName, clients, podNameArg, dryRun, removeReqs) {
  const listR = await pooled(function() { return k8sCall(function() { return clients.core.listNamespacedPod({ namespace: nsName }); }); });
  if (!listR.success) return [{ ns: nsName, error: listR.output }];
  let pods = (listR.data && listR.data.items) || [];
  if (podNameArg) pods = pods.filter(function(p) { return p.metadata.name === podNameArg; });

  return parallelMap(pods, async function(pod) {
    const podName2  = pod.metadata.name;
    const ownerRefs = pod.metadata.ownerReferences || [];
    const rsOwner   = ownerRefs.find(function(o) { return o.kind === "ReplicaSet"; });
    const stsOwner  = ownerRefs.find(function(o) { return o.kind === "StatefulSet"; });
    const dsOwner   = ownerRefs.find(function(o) { return o.kind === "DaemonSet"; });
    const jobOwner  = ownerRefs.find(function(o) { return o.kind === "Job"; });

    let targetKind = null, targetName = null;

    if (rsOwner) {
      const rsR = await pooled(function() { return k8sCall(function() { return clients.apps.readNamespacedReplicaSet({ name: rsOwner.name, namespace: nsName }); }); });
      if (rsR.success && rsR.data) {
        const depOwner = (rsR.data.metadata.ownerReferences || []).find(function(o) { return o.kind === "Deployment"; });
        if (depOwner) { targetKind = "Deployment"; targetName = depOwner.name; }
      }
    } else if (stsOwner) { targetKind = "StatefulSet"; targetName = stsOwner.name;
    } else if (dsOwner)  { targetKind = "DaemonSet";   targetName = dsOwner.name;
    } else if (jobOwner) { targetKind = "Job";          targetName = jobOwner.name; }

    const patchSpec   = JSON.parse(JSON.stringify(targetKind ? { spec: { template: { spec: pod.spec } } } : { spec: pod.spec }));
    const specToPatch = targetKind ? patchSpec.spec.template.spec : patchSpec.spec;
    const changed     = stripPodSpec(specToPatch, removeReqs);

    if (!changed) return { ns: nsName, pod: podName2, status: "no-limits", controller: targetKind || "standalone" };

    if (dryRun) {
      const containers = (pod.spec.containers || []).concat(pod.spec.initContainers || []);
      return { ns: nsName, pod: podName2, status: "would-patch", controller: targetKind || "standalone", controllerName: targetName, containers: containers.map(function(c) { return c.name; }) };
    }

    const ph = { headers: { "Content-Type": "application/merge-patch+json" } };
    let pr;
    if (targetKind === "Deployment")  pr = await pooled(function() { return k8sCall(function() { return clients.apps.patchNamespacedDeployment({ name: targetName, namespace: nsName, body: patchSpec }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); });
    else if (targetKind === "StatefulSet") pr = await pooled(function() { return k8sCall(function() { return clients.apps.patchNamespacedStatefulSet({ name: targetName, namespace: nsName, body: patchSpec }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); });
    else if (targetKind === "DaemonSet")   pr = await pooled(function() { return k8sCall(function() { return clients.apps.patchNamespacedDaemonSet({ name: targetName, namespace: nsName, body: patchSpec }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); });
    else { const podPatch = { spec: patchSpec.spec }; pr = await pooled(function() { return k8sCall(function() { return clients.core.patchNamespacedPod({ name: podName2, namespace: nsName, body: podPatch }, undefined, undefined, undefined, undefined, undefined, undefined, ph); }); }); }

    return { ns: nsName, pod: podName2, status: pr.success ? "patched" : "error", controller: targetKind || "standalone", controllerName: targetName, error: pr.success ? null : pr.output };
  });
}

export async function handleRemoveResourceLimits(args) {
  const namespaceArg = args.namespace;
  const podNameArg   = args.podName   || null;
  const dryRun       = args.dryRun    || false;
  const removeReqs   = args.removeRequests || false;

  const firstNs    = namespaceArg.replace(/\*/g, "a");
  const firstRoute = resolveNamespace(firstNs);
  const { getK8sClients } = await import("../profiles.js");
  const clients    = getK8sClients(firstRoute.profile);

  const namespaces = await resolveNamespaces(namespaceArg, clients);
  if (!namespaces.length) return { content: [{ type: "text", text: "No namespaces matched: " + namespaceArg }] };

  const nestedResults = await parallelMap(namespaces, function(nsName) {
    return processNamespace(nsName, clients, podNameArg, dryRun, removeReqs);
  });
  const all = nestedResults.reduce(function(a, r) { return a.concat(r); }, []);

  const patched    = all.filter(function(r) { return r.status === "patched"; });
  const wouldPatch = all.filter(function(r) { return r.status === "would-patch"; });
  const noLimits   = all.filter(function(r) { return r.status === "no-limits"; });
  const errors     = all.filter(function(r) { return r.status === "error"; });

  const lines = [];
  lines.push((dryRun ? "DRY RUN - " : "") + "Remove Resource Limits");
  lines.push("Pattern: " + namespaceArg + "  Namespaces: " + namespaces.length);
  lines.push("Scanned: " + all.length + "  " + (dryRun ? "Would patch: " + wouldPatch.length : "Patched: " + patched.length) + "  No limits: " + noLimits.length + "  Errors: " + errors.length);
  lines.push("");

  if (dryRun && wouldPatch.length) {
    lines.push("Would patch:");
    wouldPatch.forEach(function(r) { lines.push("  " + r.ns + "/" + r.pod + "  via " + r.controller + (r.controllerName ? "/" + r.controllerName : "") + "  containers: " + (r.containers || []).join(", ")); });
    lines.push("");
  }
  if (!dryRun && patched.length) {
    lines.push("Patched:");
    patched.forEach(function(r) { lines.push("  " + r.ns + "/" + r.pod + "  via " + r.controller + (r.controllerName ? "/" + r.controllerName : "")); });
    lines.push("");
  }
  if (errors.length) {
    lines.push("Errors:");
    errors.forEach(function(r) { lines.push("  " + r.ns + "/" + r.pod + ": " + r.error); });
  }
  if (noLimits.length && noLimits.length < 20) {
    lines.push("Already no limits:");
    noLimits.forEach(function(r) { lines.push("  " + r.ns + "/" + r.pod); });
  } else if (noLimits.length) {
    lines.push("Already no limits: " + noLimits.length + " pods");
  }

  return { content: [{ type: "text", text: lines.join("\n") }] };
}
