import { k8sCall } from "../profiles.js";

export async function genericList(clients, kind, ns) {
  const k = kind.toLowerCase();
  if (k === "pod")                   return k8sCall(function() { return clients.core.listNamespacedPod({ namespace: ns }); });
  if (k === "service")               return k8sCall(function() { return clients.core.listNamespacedService({ namespace: ns }); });
  if (k === "configmap")             return k8sCall(function() { return clients.core.listNamespacedConfigMap({ namespace: ns }); });
  if (k === "secret")                return k8sCall(function() { return clients.core.listNamespacedSecret({ namespace: ns }); });
  if (k === "event")                 return k8sCall(function() { return clients.core.listNamespacedEvent({ namespace: ns }); });
  if (k === "persistentvolumeclaim") return k8sCall(function() { return clients.core.listNamespacedPersistentVolumeClaim({ namespace: ns }); });
  if (k === "serviceaccount")        return k8sCall(function() { return clients.core.listNamespacedServiceAccount({ namespace: ns }); });
  if (k === "endpoints")             return k8sCall(function() { return clients.core.listNamespacedEndpoints({ namespace: ns }); });
  if (k === "deployment")            return k8sCall(function() { return clients.apps.listNamespacedDeployment({ namespace: ns }); });
  if (k === "statefulset")           return k8sCall(function() { return clients.apps.listNamespacedStatefulSet({ namespace: ns }); });
  if (k === "daemonset")             return k8sCall(function() { return clients.apps.listNamespacedDaemonSet({ namespace: ns }); });
  if (k === "replicaset")            return k8sCall(function() { return clients.apps.listNamespacedReplicaSet({ namespace: ns }); });
  if (k === "job")                   return k8sCall(function() { return clients.batch.listNamespacedJob({ namespace: ns }); });
  if (k === "cronjob")               return k8sCall(function() { return clients.batch.listNamespacedCronJob({ namespace: ns }); });
  if (k === "ingress")               return k8sCall(function() { return clients.net.listNamespacedIngress({ namespace: ns }); });
  if (k === "networkpolicy")         return k8sCall(function() { return clients.net.listNamespacedNetworkPolicy({ namespace: ns }); });
  if (k === "role")                  return k8sCall(function() { return clients.rbac.listNamespacedRole({ namespace: ns }); });
  if (k === "rolebinding")           return k8sCall(function() { return clients.rbac.listNamespacedRoleBinding({ namespace: ns }); });
  if (k === "clusterrole")           return k8sCall(function() { return clients.rbac.listClusterRole({}); });
  if (k === "clusterrolebinding")    return k8sCall(function() { return clients.rbac.listClusterRoleBinding({}); });
  if (k === "node")                  return k8sCall(function() { return clients.core.listNode({}); });
  if (k === "namespace")             return k8sCall(function() { return clients.core.listNamespace({}); });
  if (k === "persistentvolume")      return k8sCall(function() { return clients.core.listPersistentVolume({}); });
  return { success: false, data: null, output: "Unknown kind: " + kind };
}
