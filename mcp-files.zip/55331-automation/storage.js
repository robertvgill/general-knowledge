import fs   from "fs/promises";
import path from "path";
import { DATA_DIR } from "./config.js";

const WAL_FILE      = path.join(DATA_DIR, "knowledge.wal");
const SNAPSHOT_FILE = path.join(DATA_DIR, "knowledge.snap");
const SESSIONS_FILE = path.join(DATA_DIR, "sessions.snap");
const PATTERNS_FILE = path.join(DATA_DIR, "patterns.snap");
const LLM_FILE      = path.join(DATA_DIR, "llm.snap");

const WAL_COMPACT_THRESHOLD = 500;

async function ensureDataDir() { await fs.mkdir(DATA_DIR, { recursive: true }); }

async function readSnap(file, def) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch { return def; }
}

async function writeSnap(file, data) {
  const tmp = file + ".tmp";
  await fs.writeFile(tmp, JSON.stringify(data));
  await fs.rename(tmp, file);
}

export class KnowledgeStore {
  constructor() {
    this._knowledge  = {};
    this._invertedIdx = {};
    this._sessions   = [];
    this._patterns   = {};
    this._walEntries = 0;
    this._walHandle  = null;
  }

  async open() {
    await ensureDataDir();
    this._knowledge = await readSnap(SNAPSHOT_FILE, {});
    this._sessions  = await readSnap(SESSIONS_FILE, []);
    this._patterns  = await readSnap(PATTERNS_FILE, {});
    await this._replayWAL();
    this._rebuildInvertedIndex();
    this._walHandle = await fs.open(WAL_FILE, "a");
  }

  async _replayWAL() {
    try {
      const raw = await fs.readFile(WAL_FILE, "utf8");
      const lines = raw.split("\n").filter(function(l) { return l.trim(); });
      this._walEntries = lines.length;
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          this._applyEntry(entry);
        } catch (e) {}
      }
    } catch (e) {}
  }

  _applyEntry(entry) {
    if (entry.type === "outcome") {
      const key = entry.key;
      if (!this._knowledge[key]) this._knowledge[key] = [];
      const ex = this._knowledge[key].find(function(s) { return s.solution === entry.solution; });
      if (ex) {
        entry.success ? ex.successCount++ : ex.failCount++;
        ex.lastUsed = entry.ts;
        if (entry.fixCategory) ex.fixCategory = entry.fixCategory;
        if (entry.rootCause)   ex.rootCause   = entry.rootCause;
      } else {
        this._knowledge[key].push({
          solution:     entry.solution,
          successCount: entry.success ? 1 : 0,
          failCount:    entry.success ? 0 : 1,
          lastUsed:     entry.ts,
          fixCategory:  entry.fixCategory || "unknown",
          rootCause:    entry.rootCause   || "",
          source:       entry.source      || "manual",
          cluster:      entry.cluster     || "unknown"
        });
      }
    }
    if (entry.type === "session") {
      this._sessions.push(entry.data);
    }
    if (entry.type === "pattern") {
      for (const p of (entry.patterns || [])) {
        this._patterns[p] = (this._patterns[p] || 0) + 1;
      }
    }
  }

  _rebuildInvertedIndex() {
    this._invertedIdx = {};
    for (const key of Object.keys(this._knowledge)) {
      for (const token of ngramTokenize(key)) {
        if (!this._invertedIdx[token]) this._invertedIdx[token] = new Set();
        this._invertedIdx[token].add(key);
      }
    }
  }

  async _appendWAL(entry) {
    const line = JSON.stringify(entry) + "\n";
    if (this._walHandle) {
      await this._walHandle.write(line);
    }
    this._walEntries++;
    this._applyEntry(entry);

    if (entry.type === "outcome") {
      const key = entry.key;
      for (const token of ngramTokenize(key)) {
        if (!this._invertedIdx[token]) this._invertedIdx[token] = new Set();
        this._invertedIdx[token].add(key);
      }
    }

    if (this._walEntries >= WAL_COMPACT_THRESHOLD) {
      await this._compact();
    }
  }

  async _compact() {
    if (this._walHandle) {
      await this._walHandle.close();
      this._walHandle = null;
    }
    await writeSnap(SNAPSHOT_FILE, this._knowledge);
    await writeSnap(SESSIONS_FILE, this._sessions.slice(-500));
    await writeSnap(PATTERNS_FILE, this._patterns);
    try { await fs.unlink(WAL_FILE); } catch (e) {}
    this._walEntries = 0;
    this._walHandle  = await fs.open(WAL_FILE, "a");
  }

  async recordOutcome(key, solution, success, meta) {
    meta = meta || {};
    await this._appendWAL({
      type:        "outcome",
      key:         key,
      solution:    solution,
      success:     success,
      ts:          Date.now(),
      fixCategory: meta.fixCategory || "unknown",
      rootCause:   meta.rootCause   || "",
      source:      meta.source      || "manual",
      cluster:     meta.cluster     || "unknown"
    });
  }

  async recordPatterns(patterns) {
    if (!patterns.length) return;
    await this._appendWAL({ type: "pattern", patterns: patterns });
  }

  async recordSession(data) {
    await this._appendWAL({ type: "session", data: Object.assign({}, data, { timestamp: Date.now() }) });
  }

  getSolutions(key) {
    return this._knowledge[key] || [];
  }

  findCandidateKeys(queryKey) {
    const tokens    = ngramTokenize(queryKey);
    const scores    = {};
    const total     = tokens.length || 1;
    for (const token of tokens) {
      const matches = this._invertedIdx[token];
      if (matches) {
        for (const k of matches) {
          scores[k] = (scores[k] || 0) + 1;
        }
      }
    }
    return Object.entries(scores)
      .map(function(e) { return { key: e[0], overlap: e[1] / total }; })
      .filter(function(r) { return r.overlap > 0.1; })
      .sort(function(a, b) { return b.overlap - a.overlap; })
      .slice(0, 30)
      .map(function(r) { return r.key; });
  }

  getAllKeys() { return Object.keys(this._knowledge); }
  getSessions() { return this._sessions; }
  getPatterns() { return this._patterns; }
  getKnowledge() { return this._knowledge; }

  async saveLLMCache(cache) { await writeSnap(LLM_FILE, cache); }
  async loadLLMCache()      { return readSnap(LLM_FILE, {}); }

  async close() {
    if (this._walHandle) {
      await this._walHandle.close();
      this._walHandle = null;
    }
  }
}

function ngramTokenize(text) {
  const s      = text.toLowerCase().replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
  const words  = s.split(" ").filter(function(w) { return w.length > 1; });
  const tokens = new Set(words);
  for (const w of words) {
    if (w.length >= 3) { tokens.add(w.slice(0, 3)); }
    if (w.length >= 4) { tokens.add(w.slice(0, 4)); }
  }
  return Array.from(tokens);
}

export { ngramTokenize };
