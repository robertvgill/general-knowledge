import { MAX_CONCURRENCY } from "./config.js";

let   activeCount = 0;
const waitQueue   = [];

function acquireSlot() {
  if (activeCount < MAX_CONCURRENCY) {
    activeCount++;
    return Promise.resolve();
  }
  return new Promise(function(resolve) { waitQueue.push(resolve); });
}

function releaseSlot() {
  activeCount--;
  if (waitQueue.length > 0) {
    activeCount++;
    waitQueue.shift()();
  }
}

export async function pooled(fn) {
  await acquireSlot();
  try {
    return await fn();
  } finally {
    releaseSlot();
  }
}

export async function parallelMap(items, fn, concurrency) {
  concurrency = concurrency || MAX_CONCURRENCY;
  var results = new Array(items.length);
  var active  = 0;
  var idx     = 0;
  return new Promise(function(resolve, reject) {
    function next() {
      while (active < concurrency && idx < items.length) {
        var i = idx++;
        active++;
        Promise.resolve().then(function() { return fn(items[i], i); })
          .then(function(r) {
            results[i] = r;
            active--;
            if (idx >= items.length && active === 0) resolve(results);
            else next();
          })
          .catch(reject);
      }
    }
    if (!items.length) return resolve([]);
    next();
  });
}

export function getActiveCount() { return activeCount; }
