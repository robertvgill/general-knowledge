export function fmtPods(list) {
  if (!list || !list.items || !list.items.length) return "No pods found.";
  return list.items.map(function(p) {
    const cs      = (p.status && p.status.containerStatuses) || [];
    const ready   = cs.filter(function(c) { return c.ready; }).length + "/" + cs.length;
    const phase   = (p.status && p.status.phase) || "Unknown";
    const restart = cs.reduce(function(a, c) { return a + (c.restartCount || 0); }, 0);
    const age     = p.metadata && p.metadata.creationTimestamp
      ? Math.round((Date.now() - new Date(p.metadata.creationTimestamp).getTime()) / 60000) + "m" : "?";
    return p.metadata.name + "  " + ready + "  " + phase + "  restarts:" + restart + "  age:" + age;
  }).join("\n");
}

export function fmtEvents(list) {
  if (!list || !list.items || !list.items.length) return "No events found.";
  return list.items
    .sort(function(a, b) { return new Date(b.lastTimestamp || 0) - new Date(a.lastTimestamp || 0); })
    .slice(0, 20)
    .map(function(e) { return (e.type || "?") + "  " + (e.reason || "?") + "  " + (e.message || "").slice(0, 100); })
    .join("\n");
}

export function fmtNodes(list) {
  if (!list || !list.items || !list.items.length) return "No nodes found.";
  return list.items.map(function(n) {
    const conds  = (n.status && n.status.conditions) || [];
    const ready  = (conds.find(function(c) { return c.type === "Ready"; }) || {}).status || "Unknown";
    const labels = (n.metadata && n.metadata.labels) || {};
    const roles  = Object.keys(labels)
      .filter(function(k) { return k.startsWith("node-role.kubernetes.io/"); })
      .map(function(k) { return k.split("/")[1]; })
      .join(",") || "<none>";
    return n.metadata.name + "  Ready:" + ready + "  Roles:" + roles;
  }).join("\n");
}

export function fmtDeployments(list) {
  if (!list || !list.items || !list.items.length) return "No deployments found.";
  return list.items.map(function(d) {
    const spec = d.spec || {}, status = d.status || {};
    return d.metadata.name +
      "  desired:" + (spec.replicas || 0) +
      "  ready:"   + (status.readyReplicas || 0) +
      "  available:" + (status.availableReplicas || 0);
  }).join("\n");
}

export function fmtServices(list) {
  if (!list || !list.items || !list.items.length) return "No services found.";
  return list.items.map(function(s) {
    const spec  = s.spec || {};
    const ports = (spec.ports || []).map(function(p) { return p.port + "/" + p.protocol; }).join(",");
    return s.metadata.name + "  " + (spec.type || "ClusterIP") + "  " + (spec.clusterIP || "") + "  ports:" + ports;
  }).join("\n");
}

export function fmtConfigMaps(list) {
  if (!list || !list.items || !list.items.length) return "No configmaps found.";
  return list.items.map(function(c) {
    return c.metadata.name + "  keys:" + Object.keys(c.data || {}).join(",");
  }).join("\n");
}

export function fmtSecrets(list) {
  if (!list || !list.items || !list.items.length) return "No secrets found.";
  return list.items.map(function(s) {
    return s.metadata.name + "  type:" + s.type + "  keys:" + Object.keys(s.data || {}).join(",");
  }).join("\n");
}

export function fmtPVCs(list) {
  if (!list || !list.items || !list.items.length) return "No PVCs found.";
  return list.items.map(function(p) {
    return p.metadata.name + "  " + (p.status && p.status.phase) + "  " + (p.spec && p.spec.storageClassName);
  }).join("\n");
}

export function fmtNamespaces(list) {
  if (!list || !list.items || !list.items.length) return "No namespaces found.";
  return list.items.map(function(n) {
    return n.metadata.name + "  " + (n.status && n.status.phase);
  }).join("\n");
}

export function fmtIngresses(list) {
  if (!list || !list.items || !list.items.length) return "No ingresses found.";
  return list.items.map(function(i) {
    const rules = ((i.spec && i.spec.rules) || []).map(function(r) { return r.host || ""; }).join(",");
    return i.metadata.name + "  hosts:" + rules;
  }).join("\n");
}

export function fmtJobs(list) {
  if (!list || !list.items || !list.items.length) return "No jobs found.";
  return list.items.map(function(j) {
    return j.metadata.name +
      "  active:"    + (j.status && j.status.active    || 0) +
      "  succeeded:" + (j.status && j.status.succeeded || 0) +
      "  failed:"    + (j.status && j.status.failed    || 0);
  }).join("\n");
}

export function fmtCronJobs(list) {
  if (!list || !list.items || !list.items.length) return "No cronjobs found.";
  return list.items.map(function(c) {
    return c.metadata.name +
      "  schedule:" + (c.spec && c.spec.schedule) +
      "  lastRun:"  + (c.status && c.status.lastScheduleTime || "never");
  }).join("\n");
}

export function fmtStatefulSets(list) {
  if (!list || !list.items || !list.items.length) return "No statefulsets found.";
  return list.items.map(function(s) {
    return s.metadata.name +
      "  replicas:" + (s.spec   && s.spec.replicas      || 0) +
      "  ready:"    + (s.status && s.status.readyReplicas || 0);
  }).join("\n");
}

export function fmtDaemonSets(list) {
  if (!list || !list.items || !list.items.length) return "No daemonsets found.";
  return list.items.map(function(d) {
    return d.metadata.name +
      "  desired:" + (d.status && d.status.desiredNumberScheduled || 0) +
      "  ready:"   + (d.status && d.status.numberReady            || 0);
  }).join("\n");
}
