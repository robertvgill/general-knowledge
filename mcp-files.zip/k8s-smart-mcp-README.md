# K8s Smart MCP v2.0 — Setup Guide
# Zero API key required — uses GPT-4.1 free via VS Code Copilot

## 1. Install

```powershell
mkdir $env:USERPROFILE\k8s-smart-mcp
cd $env:USERPROFILE\k8s-smart-mcp
# Copy server-v2.js here as server.js
npm init -y
npm install @modelcontextprotocol/sdk
```

## 2. Add to mcp.json
# Location: C:\Users\<you>\AppData\Roaming\Code\User\mcp.json

```json
{
  "servers": {
    "k8s-smart-mcp": {
      "type": "stdio",
      "command": "node",
      "args": ["%USERPROFILE%\\k8s-smart-mcp\\server.js"]
    },
    "mcp/openshift": {
      "type": "stdio",
      "command": "npx",
      "args": [
        "-y",
        "kubernetes-mcp-server@latest",
        "--kubeconfig",
        "%USERPROFILE%\\kubeconfig\\openshift-config"
      ]
    }
  }
}
```

## 3. How Copilot GPT-4.1 is discovered (automatic)

VS Code sets these env vars when launching your MCP server:
  - VSCODE_PROXY_URI   — local Copilot proxy endpoint
  - VSCODE_COPILOT_TOKEN — auth token (rotated automatically)

The server reads these automatically. You do nothing.

If the proxy is not available, Engine 2 (LLM analysis) is silently
disabled and all other engines (1, 3, 4) continue working normally.

## 4. Tools available

  k8s_diagnose        — full self-learning diagnosis (all 4 engines)
  k8s_kubectl         — run any kubectl command + optional LLM analysis
  k8s_watch           — start auto-resolution watcher for a pod
  k8s_record_outcome  — manually train the AI (backup to Engine 1)
  k8s_knowledge       — query ranked solutions or view learning stats
  k8s_runbook         — execute a diagnostic playbook

## 5. Example prompts in Copilot Chat

  "Diagnose pod api-7f9c in namespace prod — it's in CrashLoopBackOff"
  "Run the oomkilled runbook for worker-node-3"
  "What solutions has the AI learned for ImagePullBackOff?"
  "Show learning statistics"
  "Watch pod nginx-abc in default after I applied the fix"

## 6. Data files (auto-created)

  ~/.k8s-smart-mcp/knowledge.json   — learned solutions + scores
  ~/.k8s-smart-mcp/sessions.json    — session history (last 500)
  ~/.k8s-smart-mcp/patterns.json    — error frequency counters
  ~/.k8s-smart-mcp/llm-cache.json   — cached GPT-4.1 analyses
