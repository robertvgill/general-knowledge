#!/usr/bin/env node
/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   K8s Smart MCP  v2.0  —  Self-Learning Troubleshooter      ║
 * ║                                                              ║
 * ║   Engine 1 — Auto-Resolution Detection (cluster polling)    ║
 * ║   Engine 2 — LLM Log Analysis (GPT-4.1 via Copilot, free)  ║
 * ║   Engine 3 — Confidence Decay (time-weighted scoring)       ║
 * ║   Engine 4 — TF-IDF Cross-Cluster Similarity Matching       ║
 * ║                                                              ║
 * ║   Zero API key required — uses VS Code Copilot GPT-4.1      ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Install:
 *   mkdir ~/k8s-smart-mcp && cd ~/k8s-smart-mcp
 *   npm install @modelcontextprotocol/sdk
 *   node server.js
 *
 * mcp.json entry:
 *   "k8s-smart-mcp": {
 *     "type": "stdio",
 *     "command": "node",
 *     "args": ["%USERPROFILE%\\k8s-smart-mcp\\server.js"]
 *   }
 */

import { Server }               from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { exec }    from "child_process";
import { promisify } from "util";
import fs   from "fs/promises";
import path from "path";
import os   from "os";
import http from "http";

const execAsync = promisify(exec);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ─── Paths ────────────────────────────────────────────────────────────────────
const DATA_DIR      = path.join(os.homedir(), ".k8s-smart-mcp");
const KNOWLEDGE_FILE = path.join(DATA_DIR, "knowledge.json");
const SESSIONS_FILE  = path.join(DATA_DIR, "sessions.json");
const PATTERNS_FILE  = path.join(DATA_DIR, "patterns.json");
const LLM_CACHE_FILE = path.join(DATA_DIR, "llm-cache.json");

// ─── Persistence ──────────────────────────────────────────────────────────────
async function ensureDataDir() { await fs.mkdir(DATA_DIR, { recursive: true }); }

async function loadJSON(file, def) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch { return def; }
}

async function saveJSON(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// ═════════════════════════════════════════════════════════════════════════════
// ENGINE 2 — LLM Analysis via GPT-4.1 (Copilot, free on your corporate plan)
// ═════════════════════════════════════════════════════════════════════════════
// VS Code Copilot exposes a local OpenAI-compatible proxy on a dynamic port.
// We discover it from the environment variable VSCODE_PROXY_URI which Copilot
// sets when the MCP server is launched from VS Code.
// Fallback: direct Copilot API via the token in VSCODE_COPILOT_TOKEN.

let llmCache = {};

async function loadLLMCache() {
  llmCache = await loadJSON(LLM_CACHE_FILE, {});
}

async function saveLLMCache() {
  // Keep last 200 cached analyses to save disk space
  const keys = Object.keys(llmCache);
  if (keys.length > 200) {
    const trimmed = {};
    keys.slice(-200).forEach(k => { trimmed[k] = llmCache[k]; });
    llmCache = trimmed;
  }
  await saveJSON(LLM_CACHE_FILE, llmCache);
}

function hashInput(s) {
  // Simple djb2 hash for cache keys
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return (h >>> 0).toString(36);
}

async function callGPT4viaProxy(prompt) {
  // Try VS Code's built-in proxy first (set when launched from VS Code)
  const proxyUri = process.env.VSCODE_PROXY_URI || process.env.COPILOT_PROXY_URI;

  if (proxyUri) {
    try {
      const url  = new URL("/v1/chat/completions", proxyUri);
      const body = JSON.stringify({
        model: "gpt-4.1",
        max_tokens: 600,
        temperature: 0,
        messages: [{ role: "user", content: prompt }],
      });

      return await httpPost(url, body, {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.VSCODE_COPILOT_TOKEN || "copilot"}`,
      });
    } catch (e) {
      // proxy failed, fall through to GitHub Copilot REST API
    }
  }

  // Fallback: GitHub Copilot API (uses OAuth token from VS Code keychain)
  // The token is injected by VS Code into GITHUB_TOKEN when running inside a
  // Dev Container or Codespace, or can be read from the VS Code secret store.
  const token = process.env.GITHUB_TOKEN || process.env.COPILOT_TOKEN;
  if (!token) return null; // Engine 2 gracefully disabled — others still work

  try {
    const url  = new URL("https://api.githubcopilot.com/chat/completions");
    const body = JSON.stringify({
      model: "gpt-4.1",
      max_tokens: 600,
      temperature: 0,
      messages: [{ role: "user", content: prompt }],
    });

    return await httpPost(url, body, {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
      "Copilot-Integration-Id": "vscode-chat",
      "Editor-Version": "vscode/1.95.0",
    });
  } catch {
    return null;
  }
}

function httpPost(url, body, headers) {
  return new Promise((resolve, reject) => {
    const isHttps = url.protocol === "https:";
    const lib     = isHttps ? (await import("https")).default : http;

    const req = lib.request({
      hostname: url.hostname,
      port:     url.port || (isHttps ? 443 : 80),
      path:     url.pathname,
      method:   "POST",
      headers:  { ...headers, "Content-Length": Buffer.byteLength(body) },
    }, (res) => {
      let data = "";
      res.on("data", c => { data += c; });
      res.on("end", () => {
        try {
          const json = JSON.parse(data);
          resolve(json.choices?.[0]?.message?.content || null);
        } catch { resolve(null); }
      });
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function analyzeWithLLM(kubectlOutput, symptom) {
  const cacheKey = hashInput(symptom + kubectlOutput.slice(0, 500));
  if (llmCache[cacheKey]) return llmCache[cacheKey]; // don't re-analyze same output

  const prompt = `You are a senior Kubernetes SRE. Analyze the kubectl output below and return ONLY a valid JSON object — no markdown, no explanation.

Symptom: ${symptom}

kubectl output (truncated to 3000 chars):
${kubectlOutput.slice(0, 3000)}

Return exactly this shape:
{
  "rootCause": "one concise sentence",
  "confidence": <0.0 to 1.0>,
  "suggestedFix": "exact kubectl command or actionable step",
  "fixCategory": "config|resource|image|network|secret|node|rbac|storage",
  "severity": "critical|high|medium|low",
  "additionalChecks": ["optional kubectl command 1", "optional kubectl command 2"]
}`;

  try {
    const raw = await callGPT4viaProxy(prompt);
    if (!raw) return null;

    const result = JSON.parse(raw.replace(/```json|```/g, "").trim());

    // Cache the result
    llmCache[cacheKey] = result;
    await saveLLMCache();

    return result;
  } catch {
    return null; // LLM analysis optional — MCP continues without it
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// ENGINE 3 — Confidence Decay (time-weighted Bayesian scoring)
// ═════════════════════════════════════════════════════════════════════════════
const HALF_LIFE_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function computeScore(solution) {
  const ageMs  = Date.now() - (solution.lastUsed || Date.now());
  const decay  = Math.exp(-0.693 * ageMs / HALF_LIFE_MS); // ln(2) = 0.693

  // Raw Laplace-smoothed success rate
  const raw = solution.successCount / (solution.successCount + solution.failCount + 1);

  // Decayed score: recent fixes count more; old knowledge floors at 30% of raw
  const score = raw * decay + raw * (1 - decay) * 0.3;

  // Boost solutions that have been tried many times (more data = more confidence)
  const trialBoost = Math.log1p(solution.successCount + solution.failCount) * 0.05;

  return Math.min(score + trialBoost, 1.0);
}

// ═════════════════════════════════════════════════════════════════════════════
// ENGINE 4 — TF-IDF Cross-Cluster Similarity Matching
// ═════════════════════════════════════════════════════════════════════════════
function tokenize(text) {
  return text.toLowerCase()
    .replace(/[^a-z0-9]/g, " ")
    .split(/\s+/)
    .filter(t => t.length > 2);
}

function buildTFIDF(docs) {
  const N   = docs.length;
  const dfs = {}; // document frequency per token

  const tfs = docs.map(doc => {
    const tokens = tokenize(doc);
    const tf     = {};
    for (const t of tokens) tf[t] = (tf[t] || 0) + 1;
    const len = tokens.length || 1;
    for (const t of Object.keys(tf)) {
      tf[t] /= len; // normalize by doc length
      dfs[t] = (dfs[t] || 0) + 1;
    }
    return tf;
  });

  return tfs.map(tf => {
    const vec = {};
    for (const [t, freq] of Object.entries(tf)) {
      vec[t] = freq * Math.log((N + 1) / (dfs[t] + 1)); // IDF with smoothing
    }
    return vec;
  });
}

function cosineSimilarity(a, b) {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  let dot = 0, magA = 0, magB = 0;
  for (const k of keys) {
    const va = a[k] || 0, vb = b[k] || 0;
    dot  += va * vb;
    magA += va * va;
    magB += vb * vb;
  }
  return dot / (Math.sqrt(magA) * Math.sqrt(magB) + 1e-10);
}

function findSimilarSymptoms(query, knowledgeKeys, threshold = 0.35) {
  if (!knowledgeKeys.length) return [];
  const corpus  = [query, ...knowledgeKeys];
  const vectors = buildTFIDF(corpus);
  const qVec    = vectors[0];

  return knowledgeKeys
    .map((key, i) => ({ key, score: cosineSimilarity(qVec, vectors[i + 1]) }))
    .filter(r => r.score >= threshold)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);
}

// ═════════════════════════════════════════════════════════════════════════════
// ENGINE 1 — Auto-Resolution Detection (cluster polling)
// ═════════════════════════════════════════════════════════════════════════════
const activeWatchers = new Map(); // podKey → { timer, symptom, solution }

async function watchResolution({ podName, namespace, symptom, solution, kubeconfig }) {
  const POLL_MS   = 15_000;  // check every 15 seconds
  const MAX_MS    = 600_000; // give up after 10 minutes
  const CONFIRM_N = 2;       // must be Running for N consecutive checks

  const start    = Date.now();
  let consecutive = 0;
  const podKey   = `${namespace}/${podName}`;

  // Cancel any existing watcher for this pod
  if (activeWatchers.has(podKey)) {
    clearTimeout(activeWatchers.get(podKey).timer);
  }

  const check = async () => {
    if (Date.now() - start > MAX_MS) {
      activeWatchers.delete(podKey);
      // No signal after 10 min — don't record (ambiguous)
      return;
    }

    const result = await runKubectl(
      `get pod ${podName} -n ${namespace} -o jsonpath='{.status.phase}'`,
      kubeconfig
    );
    const phase = result.output.replace(/'/g, "").trim();

    if (phase === "Running") {
      consecutive++;
      if (consecutive >= CONFIRM_N) {
        // ✅ Pod stayed Running — auto-record success
        await kb.recordOutcome(symptom, solution, true);
        await kb.updateLastSession(podKey, "auto-resolved");
        activeWatchers.delete(podKey);
        return;
      }
    } else if (["Failed", "Unknown", "CrashLoopBackOff"].includes(phase) ||
               result.output.includes("CrashLoop")) {
      // ❌ Still failing — auto-record failure
      await kb.recordOutcome(symptom, solution, false);
      await kb.updateLastSession(podKey, "auto-failed");
      activeWatchers.delete(podKey);
      return;
    } else {
      consecutive = 0; // reset on non-Running
    }

    // Schedule next check
    const timer = setTimeout(check, POLL_MS);
    activeWatchers.set(podKey, { timer, symptom, solution });
  };

  // First check after initial delay
  const timer = setTimeout(check, POLL_MS);
  activeWatchers.set(podKey, { timer, symptom, solution });

  return `Watching ${podKey} for auto-resolution (checks every 15s, up to 10min)`;
}

// ═════════════════════════════════════════════════════════════════════════════
// Knowledge Base (enhanced with Engine 3 + 4 scoring)
// ═════════════════════════════════════════════════════════════════════════════
class KnowledgeBase {
  constructor() {
    this.knowledge = {}; // key → [{ solution, successCount, failCount, lastUsed, fixCategory, rootCause }]
    this.sessions  = [];
    this.patterns  = {};
  }

  async load() {
    await ensureDataDir();
    this.knowledge = await loadJSON(KNOWLEDGE_FILE, {});
    this.sessions  = await loadJSON(SESSIONS_FILE,  []);
    this.patterns  = await loadJSON(PATTERNS_FILE,  {});
  }

  async save() {
    await saveJSON(KNOWLEDGE_FILE, this.knowledge);
    await saveJSON(SESSIONS_FILE,  this.sessions.slice(-500));
    await saveJSON(PATTERNS_FILE,  this.patterns);
  }

  async recordOutcome(symptom, solution, success, meta = {}) {
    const key = normalizeSymptom(symptom);
    if (!this.knowledge[key]) this.knowledge[key] = [];

    const existing = this.knowledge[key].find(s => s.solution === solution);
    if (existing) {
      if (success) existing.successCount++;
      else         existing.failCount++;
      existing.lastUsed = Date.now();
      if (meta.fixCategory) existing.fixCategory = meta.fixCategory;
      if (meta.rootCause)   existing.rootCause   = meta.rootCause;
    } else {
      this.knowledge[key].push({
        solution,
        successCount: success ? 1 : 0,
        failCount:    success ? 0 : 1,
        lastUsed:     Date.now(),
        fixCategory:  meta.fixCategory || "unknown",
        rootCause:    meta.rootCause   || "",
        source:       meta.source      || "manual", // "manual" | "auto" | "llm"
      });
    }

    for (const p of extractPatterns(symptom)) {
      this.patterns[p] = (this.patterns[p] || 0) + 1;
    }

    await this.save();
  }

  // Engine 3 + 4: ranked suggestions using decay + TF-IDF
  getSuggestions(symptom) {
    const key  = normalizeSymptom(symptom);
    const keys = Object.keys(this.knowledge);

    // Engine 4: find semantically similar symptoms
    const similar = findSimilarSymptoms(key, keys);

    // Collect solutions: exact match first, then TF-IDF similar
    const seen = new Set();
    const collected = [];

    // Exact match gets a similarity score of 1.0
    for (const sol of (this.knowledge[key] || [])) {
      const id = sol.solution;
      if (!seen.has(id)) {
        seen.add(id);
        collected.push({ ...sol, similarity: 1.0 });
      }
    }

    // Similar matches
    for (const { key: k, score } of similar) {
      if (k === key) continue;
      for (const sol of (this.knowledge[k] || [])) {
        if (!seen.has(sol.solution)) {
          seen.add(sol.solution);
          collected.push({ ...sol, similarity: score });
        }
      }
    }

    // Engine 3: sort by decay-weighted score × similarity
    return collected
      .map(s => ({ ...s, finalScore: computeScore(s) * s.similarity }))
      .sort((a, b) => b.finalScore - a.finalScore)
      .slice(0, 6);
  }

  async logSession(session) {
    this.sessions.push({ ...session, timestamp: Date.now() });
    await this.save();
  }

  async updateLastSession(podKey, outcome) {
    const last = [...this.sessions].reverse().find(s => s.podKey === podKey);
    if (last) { last.autoOutcome = outcome; await this.save(); }
  }

  getStats() {
    let totalSuccess = 0, totalFail = 0, autoLearned = 0;
    for (const sols of Object.values(this.knowledge)) {
      for (const s of sols) {
        totalSuccess += s.successCount;
        totalFail    += s.failCount;
        if (s.source === "auto" || s.source === "llm") autoLearned++;
      }
    }

    const topPatterns = Object.entries(this.patterns)
      .sort((a, b) => b[1] - a[1]).slice(0, 10)
      .map(([p, c]) => ({ pattern: p, count: c }));

    // Fix category breakdown
    const categories = {};
    for (const sols of Object.values(this.knowledge))
      for (const s of sols)
        categories[s.fixCategory || "unknown"] = (categories[s.fixCategory || "unknown"] || 0) + 1;

    return {
      totalSessions:  this.sessions.length,
      totalKnowledge: Object.keys(this.knowledge).length,
      totalSuccess, totalFail, autoLearned,
      topPatterns, categories,
    };
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function normalizeSymptom(s) {
  return s.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, " ").trim().slice(0, 120);
}

function extractPatterns(text) {
  const rx = /(crashloopbackoff|oomkilled|imagepullbackoff|errimagepull|pending|evicted|unschedulable|readiness|liveness|timeout|connection.refused|no.space.left|permission.denied|forbidden|backoff|throttling)/gi;
  const matches = [];
  let m;
  while ((m = rx.exec(text)) !== null) matches.push(m[1].toLowerCase().replace(/\./g, " "));
  return [...new Set(matches)];
}

// ─── kubectl executor ─────────────────────────────────────────────────────────
async function runKubectl(args, kubeconfig) {
  const env = { ...process.env };
  if (kubeconfig) env.KUBECONFIG = kubeconfig;
  try {
    const { stdout, stderr } = await execAsync(`kubectl ${args}`, {
      env, timeout: 30000, maxBuffer: 10 * 1024 * 1024,
    });
    return { success: true, output: stdout || stderr };
  } catch (err) {
    return { success: false, output: err.message, stderr: err.stderr || "" };
  }
}

// ─── Diagnostic Playbooks ─────────────────────────────────────────────────────
const PLAYBOOKS = {
  pod_crashloop: [
    "get pod {name} -n {namespace} -o yaml",
    "logs {name} -n {namespace} --previous --tail=150",
    "logs {name} -n {namespace} --tail=50",
    "describe pod {name} -n {namespace}",
    "get events -n {namespace} --sort-by=.lastTimestamp --field-selector involvedObject.name={name}",
  ],
  pod_pending: [
    "get pod {name} -n {namespace} -o yaml",
    "describe pod {name} -n {namespace}",
    "get nodes -o wide",
    "top nodes",
    "get events -n {namespace} --sort-by=.lastTimestamp",
    "get pvc -n {namespace}",
  ],
  pod_imagepull: [
    "describe pod {name} -n {namespace}",
    "get pod {name} -n {namespace} -o jsonpath='{.spec.containers[*].image}'",
    "get secret -n {namespace}",
    "get serviceaccount default -n {namespace} -o yaml",
  ],
  node_notready: [
    "describe node {name}",
    "get pods --all-namespaces --field-selector spec.nodeName={name}",
    "top node {name}",
    "get events --all-namespaces --field-selector involvedObject.name={name} --sort-by=.lastTimestamp",
  ],
  service_unreachable: [
    "get svc {name} -n {namespace} -o yaml",
    "get endpoints {name} -n {namespace}",
    "get pods -n {namespace} -l app={name}",
    "describe svc {name} -n {namespace}",
    "get networkpolicy -n {namespace}",
  ],
  oomkilled: [
    "get pod {name} -n {namespace} -o jsonpath='{.spec.containers[*].resources}'",
    "describe pod {name} -n {namespace}",
    "top pod {name} -n {namespace}",
    "get events -n {namespace} --field-selector involvedObject.name={name}",
  ],
  general: [
    "get pods --all-namespaces --field-selector status.phase!=Running",
    "get nodes",
    "get events --all-namespaces --sort-by=.lastTimestamp",
    "top nodes",
  ],
};

function detectPlaybook(symptom) {
  const s = symptom.toLowerCase();
  if (s.includes("oomkill") || s.includes("out of memory")) return "oomkilled";
  if (s.includes("crashloop") || s.includes("crash"))        return "pod_crashloop";
  if (s.includes("pending"))                                 return "pod_pending";
  if (s.includes("imagepull") || s.includes("errimagepull")) return "pod_imagepull";
  if (s.includes("notready")  || s.includes("not ready"))    return "node_notready";
  if (s.includes("service")   || s.includes("unreachable") || s.includes("connection refused")) return "service_unreachable";
  return "general";
}

// ═════════════════════════════════════════════════════════════════════════════
// MCP Server
// ═════════════════════════════════════════════════════════════════════════════
const kb = new KnowledgeBase();

const server = new Server(
  { name: "k8s-smart-mcp", version: "2.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "k8s_diagnose",
      description: [
        "Autonomously diagnose a Kubernetes issue using all 4 self-learning engines:",
        "• Runs the right kubectl playbook for the failure type",
        "• GPT-4.1 (via Copilot, free) analyzes logs and extracts root cause",
        "• Past solutions ranked by time-decayed success rate (Engine 3)",
        "• TF-IDF matches similar symptoms across clusters (Engine 4)",
        "• Starts background watcher to auto-detect resolution (Engine 1)",
      ].join("\n"),
      inputSchema: {
        type: "object",
        properties: {
          symptom:    { type: "string",  description: "Describe the problem, e.g. 'pod nginx-abc is in CrashLoopBackOff in namespace prod'" },
          name:       { type: "string",  description: "Resource name (pod, node, service)" },
          namespace:  { type: "string",  description: "Kubernetes namespace (default: default)" },
          kubeconfig: { type: "string",  description: "Path to kubeconfig file (optional)" },
          autoWatch:  { type: "boolean", description: "Auto-detect resolution via polling (default: true)" },
        },
        required: ["symptom"],
      },
    },
    {
      name: "k8s_kubectl",
      description: "Run any kubectl command. Output is logged to the learning session.",
      inputSchema: {
        type: "object",
        properties: {
          args:       { type: "string", description: "kubectl arguments, e.g. 'get pods -n kube-system -o wide'" },
          kubeconfig: { type: "string", description: "Path to kubeconfig (optional)" },
          analyze:    { type: "boolean", description: "Run GPT-4.1 analysis on the output (default: false)" },
          symptom:    { type: "string",  description: "Context for LLM analysis (used when analyze: true)" },
        },
        required: ["args"],
      },
    },
    {
      name: "k8s_watch",
      description: "Start auto-resolution watcher for a pod (Engine 1). Polls every 15s and automatically updates the knowledge base when the pod recovers or stays failed.",
      inputSchema: {
        type: "object",
        properties: {
          podName:    { type: "string", description: "Pod name to watch" },
          namespace:  { type: "string", description: "Namespace (default: default)" },
          symptom:    { type: "string", description: "Original symptom (for knowledge base)" },
          solution:   { type: "string", description: "Fix that was applied (for knowledge base)" },
          kubeconfig: { type: "string", description: "Path to kubeconfig (optional)" },
        },
        required: ["podName", "symptom", "solution"],
      },
    },
    {
      name: "k8s_record_outcome",
      description: "Manually record whether a fix worked. Trains the AI for future sessions. Use k8s_watch for automatic recording.",
      inputSchema: {
        type: "object",
        properties: {
          symptom:  { type: "string",  description: "The original symptom" },
          solution: { type: "string",  description: "The fix that was applied" },
          success:  { type: "boolean", description: "Did it resolve the issue?" },
        },
        required: ["symptom", "solution", "success"],
      },
    },
    {
      name: "k8s_knowledge",
      description: "Query ranked solutions for a symptom, or view overall learning statistics including Engine 3 decay scores and Engine 4 similarity matches.",
      inputSchema: {
        type: "object",
        properties: {
          symptom: { type: "string", description: "Symptom to look up (omit for global stats)" },
        },
      },
    },
    {
      name: "k8s_runbook",
      description: "Execute a full diagnostic runbook for a known failure pattern with optional GPT-4.1 analysis.",
      inputSchema: {
        type: "object",
        properties: {
          pattern:    { type: "string", enum: Object.keys(PLAYBOOKS), description: "Failure pattern" },
          name:       { type: "string", description: "Resource name" },
          namespace:  { type: "string", description: "Namespace (default: default)" },
          kubeconfig: { type: "string", description: "Path to kubeconfig (optional)" },
          analyze:    { type: "boolean", description: "Run GPT-4.1 analysis on results (default: true)" },
        },
        required: ["pattern"],
      },
    },
  ],
}));

// ─── Tool Handlers ────────────────────────────────────────────────────────────
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {

    // ── k8s_diagnose ─────────────────────────────────────────────────────────
    if (name === "k8s_diagnose") {
      const {
        symptom,
        name: resName,
        namespace   = "default",
        kubeconfig,
        autoWatch   = true,
      } = args;

      // Step 1: Select playbook
      const playbook = detectPlaybook(symptom);
      const commands = PLAYBOOKS[playbook];

      // Step 2: Run kubectl commands
      const results = [];
      let combinedOutput = "";
      for (const cmd of commands) {
        const filled = cmd
          .replace(/{name}/g,      resName   || "")
          .replace(/{namespace}/g, namespace || "default");
        const r = await runKubectl(filled, kubeconfig);
        results.push({ command: `kubectl ${filled}`, ...r });
        combinedOutput += `\n$ kubectl ${filled}\n${r.output}`;
      }

      // Step 3: Engine 2 — LLM analysis (GPT-4.1 via Copilot, free)
      const llmResult = await analyzeWithLLM(combinedOutput, symptom);

      // Step 4: Engine 3 + 4 — ranked past solutions
      const suggestions = kb.getSuggestions(symptom);

      // Step 5: If LLM found a new suggestion, pre-record it as a candidate
      if (llmResult?.suggestedFix && llmResult.confidence > 0.6) {
        // Don't record success yet — Engine 1 will do that automatically
        await kb.recordOutcome(
          symptom,
          llmResult.suggestedFix,
          false, // tentative — will be corrected by Engine 1 watcher
          { fixCategory: llmResult.fixCategory, rootCause: llmResult.rootCause, source: "llm" }
        );
      }

      // Step 6: Log session
      await kb.logSession({
        symptom, playbook,
        podKey:      `${namespace}/${resName || "?"}`,
        commandsRun: results.length,
        llmUsed:     !!llmResult,
      });

      // Step 7: Engine 1 — start auto-resolution watcher
      let watchMsg = "";
      if (autoWatch && resName) {
        const topFix = llmResult?.suggestedFix || suggestions[0]?.solution || "manual fix";
        watchMsg = await watchResolution({
          podName: resName, namespace, symptom,
          solution: topFix, kubeconfig,
        });
      }

      // ── Format output ─────────────────────────────────────────────────────
      const llmSection = llmResult ? [
        "",
        "### 🤖 GPT-4.1 Root Cause Analysis (free via Copilot)",
        `**Root Cause:** ${llmResult.rootCause}`,
        `**Confidence:** ${Math.round(llmResult.confidence * 100)}%`,
        `**Category:** ${llmResult.fixCategory} | **Severity:** ${llmResult.severity}`,
        `**Suggested Fix:** \`${llmResult.suggestedFix}\``,
        llmResult.additionalChecks?.length
          ? `**Additional Checks:** ${llmResult.additionalChecks.map(c => `\`${c}\``).join(", ")}`
          : "",
      ].filter(Boolean).join("\n") : "\n> ℹ️ GPT-4.1 analysis unavailable (Copilot proxy not detected — all other engines active)";

      const pastSection = suggestions.length
        ? suggestions.map((s, i) => {
            const pct = Math.round(s.finalScore * 100);
            const age = Math.round((Date.now() - s.lastUsed) / 86400000);
            return `${i + 1}. \`${s.solution}\`\n   Score: ${pct}% | ${s.successCount}✅ ${s.failCount}❌ | ${age}d ago | ${s.fixCategory || "?"} | similarity: ${Math.round(s.similarity * 100)}%`;
          }).join("\n")
        : "No prior experience — first occurrence of this symptom.";

      const diagSection = results
        .map(r => `\`\`\`\n$ ${r.command}\n${r.output.slice(0, 600)}\n\`\`\``)
        .join("\n");

      return {
        content: [{
          type: "text",
          text: [
            `## ⎈ K8s Smart Diagnosis — ${playbook.replace(/_/g, " ").toUpperCase()}`,
            `**Symptom:** ${symptom}`,
            `**Playbook:** ${playbook} | **Engines active:** 1 (watch) + 2 (LLM) + 3 (decay) + 4 (TF-IDF)`,
            llmSection,
            "",
            "### 📚 Ranked Past Solutions (Engine 3 + 4)",
            pastSection,
            "",
            "### 🔍 Live kubectl Output",
            diagSection,
            "",
            watchMsg ? `### 👁 Auto-Watcher (Engine 1)\n${watchMsg}` : "",
            "",
            "### ✅ Next Steps",
            "1. Apply the top-ranked fix or the GPT-4.1 suggestion above",
            "2. Engine 1 will auto-detect if the pod recovers (no action needed)",
            "3. Or call `k8s_watch` to start watching a pod after applying a fix",
            "4. Or call `k8s_record_outcome` to train the AI manually",
          ].filter(l => l !== undefined).join("\n"),
        }],
      };
    }

    // ── k8s_kubectl ──────────────────────────────────────────────────────────
    if (name === "k8s_kubectl") {
      const { args: cmdArgs, kubeconfig, analyze = false, symptom = "" } = args;
      const result = await runKubectl(cmdArgs, kubeconfig);

      let llmSection = "";
      if (analyze && result.output) {
        const llm = await analyzeWithLLM(result.output, symptom || cmdArgs);
        if (llm) {
          llmSection = [
            "",
            "### 🤖 GPT-4.1 Analysis",
            `**Root Cause:** ${llm.rootCause}`,
            `**Suggested Fix:** \`${llm.suggestedFix}\``,
            `**Confidence:** ${Math.round(llm.confidence * 100)}% | **Severity:** ${llm.severity}`,
          ].join("\n");
        }
      }

      return {
        content: [{
          type: "text",
          text: `\`\`\`\n$ kubectl ${cmdArgs}\n${result.output}\n\`\`\`${llmSection}`,
        }],
      };
    }

    // ── k8s_watch ────────────────────────────────────────────────────────────
    if (name === "k8s_watch") {
      const { podName, namespace = "default", symptom, solution, kubeconfig } = args;
      const msg = await watchResolution({ podName, namespace, symptom, solution, kubeconfig });
      return { content: [{ type: "text", text: `⎈ ${msg}\n\nThe knowledge base will be updated automatically.` }] };
    }

    // ── k8s_record_outcome ───────────────────────────────────────────────────
    if (name === "k8s_record_outcome") {
      const { symptom, solution, success } = args;
      await kb.recordOutcome(symptom, solution, success, { source: "manual" });
      const newScore = Math.round(computeScore(
        kb.knowledge[normalizeSymptom(symptom)]?.find(s => s.solution === solution) || { successCount: 1, failCount: 0, lastUsed: Date.now() }
      ) * 100);
      return {
        content: [{
          type: "text",
          text: [
            success ? "✅ Success recorded." : "❌ Failure recorded.",
            `Solution: "${solution}"`,
            `New Engine 3 score: ${newScore}%`,
            "Knowledge base updated — this solution's ranking has been adjusted.",
          ].join("\n"),
        }],
      };
    }

    // ── k8s_knowledge ────────────────────────────────────────────────────────
    if (name === "k8s_knowledge") {
      const { symptom } = args;

      if (symptom) {
        const suggestions = kb.getSuggestions(symptom);
        if (!suggestions.length) {
          return { content: [{ type: "text", text: `No knowledge found for: "${symptom}"\n\nThis is the first time this symptom has appeared.` }] };
        }
        const text = suggestions.map((s, i) => {
          const score = Math.round(s.finalScore * 100);
          const raw   = Math.round(s.successCount / (s.successCount + s.failCount + 1) * 100);
          const age   = Math.round((Date.now() - s.lastUsed) / 86400000);
          return [
            `### ${i + 1}. ${s.solution}`,
            `- **Engine 3 score (decayed):** ${score}% | **Raw rate:** ${raw}%`,
            `- **Engine 4 similarity:** ${Math.round(s.similarity * 100)}%`,
            `- ✅ ${s.successCount} success | ❌ ${s.failCount} fail | Last: ${age}d ago`,
            `- Category: ${s.fixCategory || "unknown"} | Source: ${s.source || "manual"}`,
            s.rootCause ? `- Root cause: ${s.rootCause}` : "",
          ].filter(Boolean).join("\n");
        }).join("\n\n");

        return { content: [{ type: "text", text: `## 📚 Knowledge: "${symptom}"\n\n${text}` }] };

      } else {
        const s = kb.getStats();
        const successRate = s.totalSuccess + s.totalFail > 0
          ? Math.round(s.totalSuccess / (s.totalSuccess + s.totalFail) * 100) : 0;

        const catText = Object.entries(s.categories)
          .sort((a, b) => b[1] - a[1])
          .map(([c, n]) => `  - ${c}: ${n}`).join("\n");

        return {
          content: [{
            type: "text",
            text: [
              "## 📊 K8s Smart MCP v2.0 — Learning Statistics",
              "",
              `- Sessions recorded: ${s.totalSessions}`,
              `- Unique symptoms: ${s.totalKnowledge}`,
              `- Fix success rate: ${successRate}%  (${s.totalSuccess} ✅ / ${s.totalFail} ❌)`,
              `- Auto-learned (Engine 1+2): ${s.autoLearned}`,
              `- Active watchers: ${activeWatchers.size}`,
              "",
              "### Fix Categories",
              catText || "  (none yet)",
              "",
              "### Top Error Patterns",
              s.topPatterns.map(p => `  - ${p.pattern}: ${p.count}x`).join("\n") || "  (none yet)",
            ].join("\n"),
          }],
        };
      }
    }

    // ── k8s_runbook ──────────────────────────────────────────────────────────
    if (name === "k8s_runbook") {
      const { pattern, name: resName, namespace = "default", kubeconfig, analyze = true } = args;
      const commands = PLAYBOOKS[pattern] || PLAYBOOKS.general;
      const results  = [];
      let combined   = "";

      for (const cmd of commands) {
        const filled = cmd
          .replace(/{name}/g,      resName   || "")
          .replace(/{namespace}/g, namespace || "default");
        const r = await runKubectl(filled, kubeconfig);
        results.push({ command: `kubectl ${filled}`, ...r });
        combined += `\n$ kubectl ${filled}\n${r.output}`;
      }

      let llmSection = "";
      if (analyze) {
        const llm = await analyzeWithLLM(combined, `runbook: ${pattern}`);
        if (llm) {
          llmSection = [
            "",
            "### 🤖 GPT-4.1 Analysis",
            `**Root Cause:** ${llm.rootCause}`,
            `**Suggested Fix:** \`${llm.suggestedFix}\``,
            `**Confidence:** ${Math.round(llm.confidence * 100)}% | **Severity:** ${llm.severity}`,
          ].join("\n");
        }
      }

      const output = results
        .map(r => `\`\`\`\n$ ${r.command}\n${r.output.slice(0, 800)}\n\`\`\``)
        .join("\n");

      return {
        content: [{
          type: "text",
          text: `## ⎈ Runbook: ${pattern}\n\n${output}${llmSection}`,
        }],
      };
    }

    return { content: [{ type: "text", text: `Unknown tool: ${name}` }] };

  } catch (err) {
    return {
      content: [{ type: "text", text: `Error in ${name}: ${err.message}\n${err.stack}` }],
      isError: true,
    };
  }
});

// ─── Boot ─────────────────────────────────────────────────────────────────────
await kb.load();
await loadLLMCache();

const transport = new StdioServerTransport();
await server.connect(transport);

// Cleanup watchers on exit
process.on("exit",    () => activeWatchers.forEach(w => clearTimeout(w.timer)));
process.on("SIGINT",  () => { activeWatchers.forEach(w => clearTimeout(w.timer)); process.exit(0); });
process.on("SIGTERM", () => { activeWatchers.forEach(w => clearTimeout(w.timer)); process.exit(0); });
