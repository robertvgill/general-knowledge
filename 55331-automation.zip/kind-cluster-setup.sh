#!/bin/bash
set -e

echo "=== 55331-automation Kind Cluster Setup ==="
echo ""

# ── Config ────────────────────────────────────────────────────────────
KUBECONFIG_PATH="$HOME/.kube/config_devel"
PROFILES_DIR="$HOME/.config/Code/User/.github/55331-automation"
CONTEXT="kind-cluster-ocp"

export KUBECONFIG="$KUBECONFIG_PATH"

# ── Verify cluster is reachable ───────────────────────────────────────
echo "Verifying cluster connection..."
kubectl cluster-info --context "$CONTEXT" > /dev/null 2>&1 || {
  echo "ERROR: Cannot connect to cluster. Check kubeconfig at $KUBECONFIG_PATH"
  exit 1
}
echo "  ✓ Connected to $CONTEXT"
echo ""

# ── Create OpenShift-pattern namespaces ───────────────────────────────
echo "Creating OpenShift-pattern namespaces..."
for NS in \
  credit-monitoring \
  creditmate-1 \
  creditmate-2 \
  creditmate-3; do
  kubectl create namespace "$NS" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null
  echo "  ✓ $NS"
done

# ── Create SKE-pattern namespaces ─────────────────────────────────────
echo ""
echo "Creating SKE-pattern namespaces..."
for NS in \
  t-55331-cm-dev1 \
  t-55331-cm-dev2 \
  t-55331-cm-sit1; do
  kubectl create namespace "$NS" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null
  echo "  ✓ $NS"
done

# ── Deploy workloads: credit-monitoring ───────────────────────────────
echo ""
echo "Deploying workloads in credit-monitoring..."

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cm-core-services
  namespace: credit-monitoring
spec:
  replicas: 1
  selector:
    matchLabels:
      app: cm-core-services
  template:
    metadata:
      labels:
        app: cm-core-services
    spec:
      initContainers:
        - name: init-db
          image: busybox:latest
          command: ["sh", "-c", "echo init done"]
          resources:
            limits:
              cpu: "200m"
              memory: "256Mi"
            requests:
              cpu: "100m"
              memory: "128Mi"
      containers:
        - name: cm-core-services
          image: nginx:alpine
          resources:
            limits:
              cpu: "500m"
              memory: "4Gi"
            requests:
              cpu: "100m"
              memory: "500Mi"
EOF
echo "  ✓ cm-core-services (container + initContainer limits)"

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cm-riskview-ui
  namespace: credit-monitoring
spec:
  replicas: 1
  selector:
    matchLabels:
      app: cm-riskview-ui
  template:
    metadata:
      labels:
        app: cm-riskview-ui
    spec:
      containers:
        - name: cm-riskview-ui
          image: nginx:alpine
          resources:
            limits:
              cpu: "100m"
              memory: "300Mi"
            requests:
              cpu: "10m"
              memory: "128Mi"
EOF
echo "  ✓ cm-riskview-ui (container limits only)"

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cm-credit-analytics
  namespace: credit-monitoring
spec:
  replicas: 1
  selector:
    matchLabels:
      app: cm-credit-analytics
  template:
    metadata:
      labels:
        app: cm-credit-analytics
    spec:
      containers:
        - name: cm-credit-analytics
          image: nginx:alpine
          resources:
            limits:
              cpu: "600m"
              memory: "2Gi"
            requests:
              cpu: "300m"
              memory: "1Gi"
        - name: sidecar-logger
          image: busybox:latest
          command: ["sh", "-c", "while true; do sleep 30; done"]
          resources:
            requests:
              cpu: "10m"
              memory: "32Mi"
EOF
echo "  ✓ cm-credit-analytics (1/2 containers have limits)"

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cm-no-limits
  namespace: credit-monitoring
spec:
  replicas: 1
  selector:
    matchLabels:
      app: cm-no-limits
  template:
    metadata:
      labels:
        app: cm-no-limits
    spec:
      containers:
        - name: cm-no-limits
          image: nginx:alpine
          resources:
            requests:
              cpu: "100m"
              memory: "256Mi"
EOF
echo "  ✓ cm-no-limits (no limits — requests only)"

# ── Deploy workloads: creditmate-1 ────────────────────────────────────
echo ""
echo "Deploying workloads in creditmate-1..."

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: creditmate-api
  namespace: creditmate-1
spec:
  replicas: 1
  selector:
    matchLabels:
      app: creditmate-api
  template:
    metadata:
      labels:
        app: creditmate-api
    spec:
      containers:
        - name: creditmate-api
          image: nginx:alpine
          resources:
            limits:
              cpu: "300m"
              memory: "512Mi"
            requests:
              cpu: "100m"
              memory: "256Mi"
EOF
echo "  ✓ creditmate-api (limits set)"

# ── Deploy workloads: t-55331-cm-dev1 ────────────────────────────────
echo ""
echo "Deploying workloads in t-55331-cm-dev1..."

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ske-core-service
  namespace: t-55331-cm-dev1
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ske-core-service
  template:
    metadata:
      labels:
        app: ske-core-service
    spec:
      initContainers:
        - name: init-check
          image: busybox:latest
          command: ["sh", "-c", "echo ready"]
          resources:
            limits:
              cpu: "100m"
              memory: "128Mi"
      containers:
        - name: ske-core-service
          image: nginx:alpine
          resources:
            limits:
              cpu: "300m"
              memory: "512Mi"
            requests:
              cpu: "100m"
              memory: "256Mi"
EOF
echo "  ✓ ske-core-service (container + initContainer limits)"

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ske-no-limits
  namespace: t-55331-cm-dev1
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ske-no-limits
  template:
    metadata:
      labels:
        app: ske-no-limits
    spec:
      containers:
        - name: ske-no-limits
          image: nginx:alpine
          resources:
            requests:
              cpu: "50m"
              memory: "64Mi"
EOF
echo "  ✓ ske-no-limits (no limits)"

# ── Write profiles.json ───────────────────────────────────────────────
echo ""
echo "Writing profiles.json..."
mkdir -p "$PROFILES_DIR"

cat > "$PROFILES_DIR/profiles.json" <<EOF
{
  "profiles": [
    {
      "name": "openshift-local",
      "kubeconfig": "$KUBECONFIG_PATH",
      "context": "$CONTEXT",
      "cluster": "openshift",
      "namespacePattern": "^credit|^crm"
    },
    {
      "name": "ske-local",
      "kubeconfig": "$KUBECONFIG_PATH",
      "context": "$CONTEXT",
      "cluster": "ske",
      "namespacePattern": "^t-55331-"
    }
  ]
}
EOF
echo "  ✓ $PROFILES_DIR/profiles.json"

# ── Summary ───────────────────────────────────────────────────────────
echo ""
echo "=========================================="
echo "✅ Setup complete!"
echo ""
echo "Kind cluster  : $CONTEXT"
echo "Kubeconfig      : $KUBECONFIG_PATH"
echo ""
echo "OpenShift namespaces:"
echo "  credit-monitoring  — 3 with limits, 1 without"
echo "  creditmate-1       — 1 with limits"
echo "  creditmate-2/3     — empty"
echo ""
echo "SKE namespaces:"
echo "  t-55331-cm-dev1    — 1 with limits, 1 without"
echo "  t-55331-cm-dev2    — empty"
echo "  t-55331-cm-sit1    — empty"
echo ""
echo "Test MCP tools:"
echo "  remove_resource_limits namespace=credit-monitoring dryRun=true"
echo "  remove_resource_limits namespace=t-55331-cm-dev1 dryRun=true"
echo "  remove_resource_limits namespace=creditmate-* dryRun=true"
echo "=========================================="
