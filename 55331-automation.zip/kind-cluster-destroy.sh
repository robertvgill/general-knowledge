#!/bin/bash
set -e

echo "=== 55331-automation Kind Cluster Destroy ==="
echo ""

KUBECONFIG_PATH="$HOME/.kube/config_devel"
CONTEXT="kind-cluster-ocp"

export KUBECONFIG="$KUBECONFIG_PATH"

# ── Verify cluster is reachable ───────────────────────────────────────
echo "Verifying cluster connection..."
kubectl cluster-info --context "$CONTEXT" > /dev/null 2>&1 || {
  echo "ERROR: Cannot connect to cluster. Check kubeconfig at $KUBECONFIG_PATH"
  exit 1
}
echo "  ✓ Connected to $CONTEXT"
echo ""

# ── Delete OpenShift-pattern namespaces ───────────────────────────────
echo "Deleting OpenShift-pattern namespaces..."
for NS in \
  credit-monitoring \
  creditmate-1 \
  creditmate-2 \
  creditmate-3; do
  kubectl delete namespace "$NS" --ignore-not-found=true
  echo "  ✓ $NS deleted"
done

# ── Delete SKE-pattern namespaces ─────────────────────────────────────
echo ""
echo "Deleting SKE-pattern namespaces..."
for NS in \
  t-55331-cm-dev1 \
  t-55331-cm-dev2 \
  t-55331-cm-sit1; do
  kubectl delete namespace "$NS" --ignore-not-found=true
  echo "  ✓ $NS deleted"
done

# ── Remove profiles.json ──────────────────────────────────────────────
echo ""
echo "Removing profiles.json..."
PROFILES_FILE="$HOME/.config/Code/User/.github/55331-automation/profiles.json"
if [ -f "$PROFILES_FILE" ]; then
  rm "$PROFILES_FILE"
  echo "  ✓ $PROFILES_FILE removed"
else
  echo "  - profiles.json not found, skipping"
fi

# ── Summary ───────────────────────────────────────────────────────────
echo ""
echo "=========================================="
echo "✅ Destroy complete!"
echo ""
echo "Verify:"
echo "  kubectl --kubeconfig $KUBECONFIG_PATH get namespaces"
echo "=========================================="
