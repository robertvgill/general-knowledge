import * as k8s from "@kubernetes/client-node";
import fs        from "fs/promises";
import { PROFILES_FILE, DEFAULT_PROFILES } from "./config.js";

let PROFILES = [];
const CLIENT_CACHE = {};

export async function loadProfiles() {
  try {
    const raw    = await fs.readFile(PROFILES_FILE, "utf8");
    const parsed = JSON.parse(raw);
    PROFILES     = parsed.profiles || parsed;
  } catch (e) {
    PROFILES = DEFAULT_PROFILES;
  }
}

export function getProfiles() { return PROFILES; }

export function getProfileForNamespace(namespace) {
  const s = namespace.toLowerCase();
  for (const p of PROFILES) {
    if (new RegExp(p.namespacePattern).test(s)) return p;
  }
  return PROFILES.find(function(p) { return p.cluster === "openshift"; }) || PROFILES[0];
}

export function expandPath(p) {
  return p.replace(/%([^%]+)%/g, function(_, k) { return process.env[k] || _; });
}

export function getK8sClients(profile) {
  if (CLIENT_CACHE[profile.name]) return CLIENT_CACHE[profile.name];

  const kc = new k8s.KubeConfig();
  kc.loadFromFile(expandPath(profile.kubeconfig));
  if (profile.context) {
    try { kc.setCurrentContext(profile.context); } catch (e) {}
  }

  const clients = {
    core:    kc.makeApiClient(k8s.CoreV1Api),
    apps:    kc.makeApiClient(k8s.AppsV1Api),
    batch:   kc.makeApiClient(k8s.BatchV1Api),
    rbac:    kc.makeApiClient(k8s.RbacAuthorizationV1Api),
    net:     kc.makeApiClient(k8s.NetworkingV1Api),
    custom:  kc.makeApiClient(k8s.CustomObjectsApi),
    metrics: kc.makeApiClient(k8s.Metrics),
    storage: kc.makeApiClient(k8s.StorageV1Api),
    kc:      kc,
  };

  CLIENT_CACHE[profile.name] = clients;
  return clients;
}

export function invalidateClientCache(profileName) {
  delete CLIENT_CACHE[profileName];
}

export async function k8sCall(fn) {
  try {
    const result = await fn();
    let data;
    if (result && result.body !== undefined) {
      data = result.body;
    } else if (result && result.items !== undefined) {
      data = result;
    } else if (result && result.metadata !== undefined) {
      data = result;
    } else if (result && typeof result === "object") {
      data = result;
    } else {
      data = result;
    }
    return { success: true, data: data };
  } catch (err) {
    const msg = (err.body && err.body.message) || err.message || String(err);
    return { success: false, data: null, output: msg };
  }
}


export async function k8sPatch(profile, url, body) {
  const kc = new k8s.KubeConfig();
  kc.loadFromFile(expandPath(profile.kubeconfig));
  if (profile.context) { try { kc.setCurrentContext(profile.context); } catch (e) {} }

  const cluster  = kc.getCurrentCluster();
  const user     = kc.getCurrentUser();
  const server   = new URL(cluster.server);
  const fs2      = await import("fs");
  const https2   = await import("https");

  const tlsOpts  = {};
  if (cluster.caData)      tlsOpts.ca   = Buffer.from(cluster.caData, "base64");
  else if (cluster.caFile) tlsOpts.ca   = fs2.default.readFileSync(cluster.caFile);
  else                     tlsOpts.rejectUnauthorized = false;

  if (user.certData)       tlsOpts.cert = Buffer.from(user.certData, "base64");
  else if (user.certFile)  tlsOpts.cert = fs2.default.readFileSync(user.certFile);

  if (user.keyData)        tlsOpts.key  = Buffer.from(user.keyData, "base64");
  else if (user.keyFile)   tlsOpts.key  = fs2.default.readFileSync(user.keyFile);

  const bodyStr = JSON.stringify(body);
  const opts    = {};
  await kc.applyToFetchOptions(opts);
  const authHeader = (opts.headers && opts.headers["Authorization"]) ? opts.headers["Authorization"] : "";

  return new Promise(function(resolve) {
    const req = https2.default.request({
      hostname:           server.hostname,
      port:               server.port || 443,
      path:               url,
      method:             "PATCH",
      ca:                 tlsOpts.ca,
      cert:               tlsOpts.cert,
      key:                tlsOpts.key,
      rejectUnauthorized: tlsOpts.rejectUnauthorized !== false,
      headers: {
        "Content-Type":   "application/strategic-merge-patch+json",
        "Accept":         "application/json",
        "Content-Length": Buffer.byteLength(bodyStr),
        "Authorization":  authHeader
      }
    }, function(res) {
      let data = "";
      res.on("data", function(c) { data += c; });
      res.on("end", function() {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve({ success: true,  data: JSON.parse(data) }); }
          catch (e) { resolve({ success: true, data: data }); }
        } else {
          resolve({ success: false, data: null, output: "HTTP-Code: " + res.statusCode + "\n" + data });
        }
      });
    });
    req.on("error", function(e) { resolve({ success: false, data: null, output: e.message }); });
    req.write(bodyStr);
    req.end();
  });
}
