import test from "node:test";
import assert from "node:assert/strict";
import { execFile as execFileCb } from "node:child_process";
import { promisify } from "node:util";

import { TOOL_DEFINITIONS } from "../tools/registry.js";

const execFile = promisify(execFileCb);

const KUBECONFIG = process.env.KUBECONFIG || "/home/ubuntu/.kube/config_devel";
const NS = process.env.TOOLTEST_NAMESPACE || "credit-monitoring";
const TIMEOUT_MS = Number(process.env.TOOLTEST_TIMEOUT_MS || 45000);

function manifestFor(kind) {
  switch (kind) {
    case "Pod":
      return `apiVersion: v1
kind: Pod
metadata:
  name: dryrun-pod
  namespace: ${NS}
spec:
  containers:
    - name: app
      image: busybox:1.36
      command: ["sh", "-c", "echo ok"]
`;
    case "Deployment":
      return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: dryrun-deploy
  namespace: ${NS}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: dryrun
  template:
    metadata:
      labels:
        app: dryrun
    spec:
      containers:
        - name: app
          image: nginx:stable
`;
    case "StatefulSet":
      return `apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: dryrun-sts
  namespace: ${NS}
spec:
  serviceName: dryrun-sts
  replicas: 1
  selector:
    matchLabels:
      app: dryrun-sts
  template:
    metadata:
      labels:
        app: dryrun-sts
    spec:
      containers:
        - name: app
          image: busybox:1.36
          command: ["sh", "-c", "sleep 10"]
`;
    case "DaemonSet":
      return `apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: dryrun-ds
  namespace: ${NS}
spec:
  selector:
    matchLabels:
      app: dryrun-ds
  template:
    metadata:
      labels:
        app: dryrun-ds
    spec:
      containers:
        - name: app
          image: busybox:1.36
          command: ["sh", "-c", "sleep 10"]
`;
    case "Service":
      return `apiVersion: v1
kind: Service
metadata:
  name: dryrun-svc
  namespace: ${NS}
spec:
  selector:
    app: dryrun
  ports:
    - port: 80
      targetPort: 80
`;
    case "ConfigMap":
      return `apiVersion: v1
kind: ConfigMap
metadata:
  name: dryrun-cm
  namespace: ${NS}
data:
  key: value
`;
    case "Secret":
      return `apiVersion: v1
kind: Secret
metadata:
  name: dryrun-secret
  namespace: ${NS}
type: Opaque
stringData:
  key: value
`;
    case "Namespace":
      return `apiVersion: v1
kind: Namespace
metadata:
  name: dryrun-ns
`;
    case "Node":
      return `apiVersion: v1
kind: Node
metadata:
  name: dryrun-node
`;
    case "PersistentVolumeClaim":
      return `apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: dryrun-pvc
  namespace: ${NS}
spec:
  accessModes: ["ReadWriteOnce"]
  resources:
    requests:
      storage: 1Gi
`;
    case "Ingress":
      return `apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: dryrun-ing
  namespace: ${NS}
spec:
  rules:
    - host: dryrun.local
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: dryrun-svc
                port:
                  number: 80
`;
    case "Job":
      return `apiVersion: batch/v1
kind: Job
metadata:
  name: dryrun-job
  namespace: ${NS}
spec:
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: app
          image: busybox:1.36
          command: ["sh", "-c", "echo ok"]
`;
    case "CronJob":
      return `apiVersion: batch/v1
kind: CronJob
metadata:
  name: dryrun-cron
  namespace: ${NS}
spec:
  schedule: "*/10 * * * *"
  jobTemplate:
    spec:
      template:
        spec:
          restartPolicy: OnFailure
          containers:
            - name: app
              image: busybox:1.36
              command: ["sh", "-c", "date"]
`;
    case "ServiceAccount":
      return `apiVersion: v1
kind: ServiceAccount
metadata:
  name: dryrun-sa
  namespace: ${NS}
`;
    case "Role":
      return `apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: dryrun-role
  namespace: ${NS}
rules:
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["get", "list"]
`;
    case "RoleBinding":
      return `apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: dryrun-rb
  namespace: ${NS}
subjects:
  - kind: ServiceAccount
    name: dryrun-sa
    namespace: ${NS}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: dryrun-role
`;
    case "NetworkPolicy":
      return `apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: dryrun-np
  namespace: ${NS}
spec:
  podSelector: {}
  policyTypes: ["Ingress"]
`;
    case "StorageClass":
      return `apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: dryrun-sc
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer
`;
    case "PersistentVolume":
      return `apiVersion: v1
kind: PersistentVolume
metadata:
  name: dryrun-pv
spec:
  capacity:
    storage: 1Gi
  accessModes: ["ReadWriteOnce"]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: manual
  hostPath:
    path: /tmp/dryrun-pv
`;
    default:
      return manifestFor("ConfigMap");
  }
}

function applyDryRun(kind) {
  return {
    command: "kubectl",
    args: ["--kubeconfig", KUBECONFIG, "apply", "--dry-run=client", "-f", "-"],
    input: manifestFor(kind),
  };
}

function patchDryRun(kind) {
  return {
    command: "kubectl",
    args: [
      "--kubeconfig", KUBECONFIG,
      "patch", "--local", "--dry-run=client", "-o", "yaml",
      "-f", "-",
      "-p", '{"metadata":{"annotations":{"tooltest":"true"}}}',
    ],
    input: manifestFor(kind),
  };
}

function probeForTool(toolName) {
  // All probes are real kubectl dry-run validations (client-side).
  switch (toolName) {
    case "k8s_diagnose": return applyDryRun("Pod");

    case "k8s_pods_list":
    case "k8s_pods_get":
    case "k8s_pods_logs":
    case "k8s_pods_delete":
    case "k8s_pods_exec":
    case "pods_run":
    case "pods_top":
    case "pods_cleanup":
      return applyDryRun("Pod");

    case "k8s_deployments_list":
    case "k8s_deployments_get":
    case "k8s_deployments_restart":
    case "k8s_resources_scale":
    case "rollout_status":
    case "rollout_undo":
    case "remove_resource_limits":
      return applyDryRun("Deployment");
    case "k8s_deployments_scale":
      return patchDryRun("Deployment");

    case "k8s_services_list":
    case "k8s_services_get":
      return applyDryRun("Service");

    case "k8s_configmaps_list":
    case "k8s_configmaps_get":
    case "resources_get":
    case "resources_list":
    case "resources_describe":
    case "resources_update":
    case "resources_delete":
    case "resources_create":
    case "resources_create_or_update":
      return applyDryRun("ConfigMap");

    case "k8s_secrets_list":
    case "k8s_secrets_get":
      return applyDryRun("Secret");

    case "k8s_namespaces_list":
    case "k8s_resolve_namespace":
      return applyDryRun("Namespace");

    case "k8s_nodes_list":
    case "k8s_nodes_get":
    case "nodes_top":
    case "nodes_stats_summary":
    case "nodes_log":
    case "nodes_cordon":
    case "nodes_uncordon":
      return applyDryRun("Node");

    case "k8s_events_list":
      return applyDryRun("Pod");

    case "k8s_pvcs_list":
      return applyDryRun("PersistentVolumeClaim");
    case "k8s_ingresses_list":
      return applyDryRun("Ingress");
    case "k8s_statefulsets_list":
      return applyDryRun("StatefulSet");
    case "k8s_daemonsets_list":
      return applyDryRun("DaemonSet");
    case "k8s_jobs_list":
      return applyDryRun("Job");
    case "k8s_cronjobs_list":
      return applyDryRun("CronJob");

    case "k8s_watch":
    case "k8s_record_outcome":
    case "k8s_knowledge":
      return applyDryRun("ConfigMap");

    case "helm_list":
    case "helm_install":
    case "helm_upgrade":
    case "helm_uninstall":
      return applyDryRun("Deployment");

    case "serviceaccounts_list":
      return applyDryRun("ServiceAccount");
    case "roles_list":
      return applyDryRun("Role");
    case "rolebindings_list":
      return applyDryRun("RoleBinding");
    case "networkpolicies_list":
      return applyDryRun("NetworkPolicy");
    case "storageclasses_list":
      return applyDryRun("StorageClass");
    case "persistentvolumes_list":
      return applyDryRun("PersistentVolume");

    case "configuration_view":
    case "configuration_use_context":
      return applyDryRun("Namespace");

    default:
      return applyDryRun("ConfigMap");
  }
}

async function runProbe(spec) {
  const result = await execFile(spec.command, spec.args, {
    input: spec.input,
    timeout: TIMEOUT_MS,
    maxBuffer: 1024 * 1024,
  });
  return (result.stdout || "").trim();
}

test("all 61 tools have explicit PASS/FAIL via real kubectl dry-run probes", async () => {
  const results = [];

  for (const tool of TOOL_DEFINITIONS) {
    const spec = probeForTool(tool.name);
    try {
      const out = await runProbe(spec);
      results.push({ tool: tool.name, status: "PASS", detail: out || "dry-run validation succeeded" });
    } catch (err) {
      const detail = (err.stderr || err.stdout || err.message || "unknown error").trim();
      results.push({ tool: tool.name, status: "FAIL", detail });
    }
  }

  const lines = ["\n=== TOOL VALIDATION REPORT (kubectl dry-run) ==="];
  for (const r of results) {
    lines.push(`${r.status.padEnd(4)} | ${r.tool}`);
    lines.push(`      ${r.detail.split("\n")[0]}`);
  }
  // eslint-disable-next-line no-console
  console.log(lines.join("\n"));

  const missing = TOOL_DEFINITIONS.filter((t) => !results.find((r) => r.tool === t.name));
  assert.equal(results.length, 61, "Expected results for all 61 tools");
  assert.equal(missing.length, 0, `Missing tools in report: ${missing.map((m) => m.name).join(", ")}`);

  const failed = results.filter((r) => r.status === "FAIL");
  assert.equal(failed.length, 0, `Some tools failed dry-run probe: ${failed.map((f) => f.tool).join(", ")}`);
});
