export const TOOL_DEFINITIONS = [
  { name: "k8s_diagnose", description: "PRIMARY tool for ALL Kubernetes issues. Runs all 4 self-learning engines. Auto-routes to correct cluster.", inputSchema: { type: "object", properties: { symptom: { type: "string" }, namespace: { type: "string" }, name: { type: "string" }, autoWatch: { type: "boolean" } }, required: ["symptom", "namespace"] } },

  { name: "k8s_pods_list",       description: "List all pods in a namespace.",           inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_pods_get",        description: "Get details of a specific pod.",           inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "k8s_pods_logs",       description: "Get logs from a pod.",                     inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, previous: { type: "boolean" }, tailLines: { type: "number" }, container: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "k8s_pods_delete",     description: "Delete a pod.",                            inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "k8s_pods_exec",       description: "Execute a command in a pod container.",    inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, command: { type: "array", items: { type: "string" } }, container: { type: "string" } }, required: ["namespace", "name", "command"] } },

  { name: "k8s_deployments_list",    description: "List deployments in a namespace.",     inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_deployments_get",     description: "Get details of a deployment.",         inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "k8s_deployments_scale",   description: "Scale a deployment.",                  inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, replicas: { type: "number" } }, required: ["namespace", "name", "replicas"] } },
  { name: "k8s_deployments_restart", description: "Rollout restart a deployment.",        inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "k8s_services_list",   description: "List services in a namespace.",            inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_services_get",    description: "Get details of a service.",                inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "k8s_configmaps_list", description: "List configmaps in a namespace.",          inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_configmaps_get",  description: "Get a configmap.",                         inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "k8s_secrets_list",    description: "List secret names in a namespace (values hidden).", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_secrets_get",     description: "Get secret metadata (values hidden).",     inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "k8s_namespaces_list", description: "List all namespaces in the cluster.",      inputSchema: { type: "object", properties: { namespace: { type: "string", description: "Any namespace to determine which cluster" } }, required: ["namespace"] } },

  { name: "k8s_nodes_list",      description: "List all nodes in the cluster.",           inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_nodes_get",       description: "Get details of a specific node.",          inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "k8s_events_list",     description: "List events in a namespace.",              inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_pvcs_list",       description: "List PersistentVolumeClaims.",             inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_ingresses_list",  description: "List ingresses in a namespace.",           inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_statefulsets_list", description: "List statefulsets.",                     inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_daemonsets_list",   description: "List daemonsets.",                       inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_jobs_list",         description: "List jobs.",                             inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_cronjobs_list",     description: "List cronjobs.",                         inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },

  { name: "k8s_resources_scale",   description: "Scale any Deployment or StatefulSet.",  inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, kind: { type: "string", enum: ["Deployment", "StatefulSet"] }, replicas: { type: "number" } }, required: ["namespace", "name", "kind", "replicas"] } },

  { name: "k8s_resolve_namespace", description: "Resolve a namespace to its cluster and profile.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "k8s_watch",            description: "Watch a pod for auto-resolution.", inputSchema: { type: "object", properties: { podName: { type: "string" }, namespace: { type: "string" }, symptom: { type: "string" }, solution: { type: "string" } }, required: ["podName", "namespace", "symptom", "solution"] } },
  { name: "k8s_record_outcome",   description: "Manually record whether a fix worked. Trains the AI.", inputSchema: { type: "object", properties: { symptom: { type: "string" }, solution: { type: "string" }, success: { type: "boolean" }, namespace: { type: "string" } }, required: ["symptom", "solution", "success"] } },
  { name: "k8s_knowledge",        description: "Query ranked solutions for a symptom, or call with no parameters to view learning statistics and counts.", inputSchema: { type: "object", properties: { symptom: { type: "string" }, cluster: { type: "string", enum: ["openshift", "ske", "all"] } } } },

  { name: "pods_run",              description: "Run a container image in a new pod.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, image: { type: "string" }, port: { type: "number" }, expose: { type: "boolean" } }, required: ["namespace", "name", "image"] } },
  { name: "pods_top",              description: "Get pod CPU and memory usage.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace"] } },
  { name: "pods_cleanup",          description: "Delete all failed/evicted/completed pods.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },

  { name: "nodes_top",             description: "Get node CPU and memory usage.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "nodes_stats_summary",   description: "Get detailed node stats.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "nodes_log",             description: "Get kubelet logs from a node.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, tailLines: { type: "number" } }, required: ["namespace", "name"] } },
  { name: "nodes_cordon",          description: "Cordon a node.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },
  { name: "nodes_uncordon",        description: "Uncordon a node.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "rollout_status",  description: "Get rollout status for a Deployment, StatefulSet or DaemonSet.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string", enum: ["Deployment","StatefulSet","DaemonSet"] }, name: { type: "string" } }, required: ["namespace","kind","name"] } },
  { name: "rollout_undo",    description: "Rollback a Deployment, StatefulSet or DaemonSet.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string", enum: ["Deployment","StatefulSet","DaemonSet"] }, name: { type: "string" } }, required: ["namespace","kind","name"] } },

  { name: "helm_list",      description: "List Helm releases.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "helm_install",   description: "Install a Helm chart.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, chart: { type: "string" }, repo: { type: "string" }, values: { type: "object" } }, required: ["namespace", "name", "chart"] } },
  { name: "helm_upgrade",   description: "Upgrade a Helm release.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" }, chart: { type: "string" }, values: { type: "object" } }, required: ["namespace", "name", "chart"] } },
  { name: "helm_uninstall", description: "Uninstall a Helm release.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, name: { type: "string" } }, required: ["namespace", "name"] } },

  { name: "resources_get",    description: "Get any Kubernetes resource by kind and name.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" }, name: { type: "string" } }, required: ["namespace","kind","name"] } },
  { name: "resources_list",   description: "List any Kubernetes resource type.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" } }, required: ["namespace","kind"] } },
  { name: "resources_describe", description: "Describe any Kubernetes resource with events.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" }, name: { type: "string" } }, required: ["namespace","kind","name"] } },
  { name: "resources_update",  description: "Update a Kubernetes resource via merge patch.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" }, name: { type: "string" }, patch: { type: "object" } }, required: ["namespace","kind","name","patch"] } },
  { name: "resources_delete",  description: "Delete a Kubernetes resource.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" }, name: { type: "string" } }, required: ["namespace","kind","name"] } },
  { name: "resources_create",  description: "Create a resource (use resources_create_or_update for full apply).", inputSchema: { type: "object", properties: { namespace: { type: "string" }, kind: { type: "string" }, manifest: { type: "object" } }, required: ["namespace","kind","manifest"] } },
  { name: "resources_create_or_update", description: "Apply a full Kubernetes manifest (create or update).", inputSchema: { type: "object", properties: { namespace: { type: "string" }, manifest: { type: "object" } }, required: ["namespace","manifest"] } },

  { name: "serviceaccounts_list", description: "List service accounts.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "roles_list",           description: "List roles.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "rolebindings_list",    description: "List rolebindings.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "networkpolicies_list", description: "List network policies.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "storageclasses_list",  description: "List storage classes.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "persistentvolumes_list", description: "List persistent volumes.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },

  { name: "configuration_view",        description: "View kubeconfig contexts.", inputSchema: { type: "object", properties: { namespace: { type: "string" } }, required: ["namespace"] } },
  { name: "configuration_use_context", description: "Switch kubeconfig context.", inputSchema: { type: "object", properties: { namespace: { type: "string" }, context: { type: "string" } }, required: ["namespace","context"] } },

  { name: "remove_resource_limits", description: [
      "IMPORTANT: Call THIS tool directly when asked to remove, strip, or clear resource limits or CPU/memory limits from pods, containers, initContainers, or sidecars.",
      "DO NOT use resources_delete or resources_describe for this operation.",
      "This tool patches the spec.containers[].resources.limits field to null on Deployments, StatefulSets, and DaemonSets.",
      "Supports wildcard namespace patterns e.g. creditmate-* or t-55331-cm-*.",
      "Dry-run mode available. Does NOT remove requests unless removeRequests is true."
    ].join(" "), inputSchema: { type: "object", properties: {
      namespace:       { type: "string",  description: "Namespace or wildcard e.g. creditmate-*" },
      podName:         { type: "string",  description: "Specific pod (optional)" },
      dryRun:          { type: "boolean", description: "Preview only. Default: false" },
      removeRequests:  { type: "boolean", description: "Also remove requests. Default: false" }
    }, required: ["namespace"] }
  },
];
