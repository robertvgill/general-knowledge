# 55331-automation v5.0 — Complete Deployment Package

## File Destinations

### Project files → C:\Users\8217908\ado_repos\55331\55331-automation\
```
project/
  server.js
  config.js
  profiles.js
  routing.js
  concurrency.js
  knowledge.js
  storage.js
  similarity.js
  formatters.js
  setup.js
  package.json
  tools/
    registry.js
    generic.js
    limits.js
```

### Supporting files
| File | Destination |
|------|-------------|
| profiles.json | %APPDATA%\Code\User\.github\55331-automation\profiles.json |
| global.instructions.md | %APPDATA%\Code\User\.github\instructions\global.instructions.md |

## Install & Setup
```
cd C:\Users\8217908\ado_repos\55331\55331-automation
npm install
node setup.js
```

## Key Fixes in This Version
- concurrency.js: Fixed parallelMap closure bug (was processing only 1 item)
- profiles.js: Fixed k8sCall for @kubernetes/client-node v1.4.0 (no .body wrapper)
- tools/limits.js: Full rewrite — scans Deployments/StatefulSets/DaemonSets/DeploymentConfigs directly, strategic-merge-patch for OpenShift
- storage.js + similarity.js: Phase 3 WAL storage + weighted cosine similarity
- setup.js: Auto-configures VS Code + IntelliJ mcp.json on Windows and MacOS
