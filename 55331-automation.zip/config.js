import path from "path";
import os   from "os";
import fs   from "fs";

export const MAX_CONCURRENCY = 100;

function profilesFilePath() {
  const home = os.homedir();
  const plat = os.platform();

  if (plat === "win32") {
    return path.join(home, "AppData", "Roaming", "Code", "User", ".github", "55331-automation", "profiles.json");
  }

  // VS Code Server on WSL/Linux
  const vscodeServer = path.join(home, ".vscode-server", "data", "User", ".github", "55331-automation", "profiles.json");
  if (fs.existsSync(vscodeServer)) return vscodeServer;

  // VS Code native on Linux/MacOS
  const vscodeNative = path.join(home, ".config", "Code", "User", ".github", "55331-automation", "profiles.json");
  if (fs.existsSync(vscodeNative)) return vscodeNative;

  // MacOS
  if (plat === "darwin") {
    return path.join(home, "Library", "Application Support", "Code", "User", ".github", "55331-automation", "profiles.json");
  }

  return vscodeNative;
}

export const PROFILES_FILE = profilesFilePath();

export const DEFAULT_PROFILES = [
  {
    name:             "openshift-local",
    kubeconfig:       "/home/ubuntu/.kube/config_devel",
    cluster:          "openshift",
    namespacePattern: "^credit|^crm"
  },
  {
    name:             "ske-local",
    kubeconfig:       "/home/ubuntu/.kube/config_devel",
    cluster:          "ske",
    namespacePattern: "^t-55331-"
  }
];

export const DATA_DIR = path.join(os.homedir(), ".55331-automation");

function intellijConfigPath() {
  const home = os.homedir();
  const plat = os.platform();
  if (plat === "win32")  return path.join(home, "AppData", "Roaming", "JetBrains");
  if (plat === "darwin") return path.join(home, "Library", "Application Support", "JetBrains");
  return path.join(home, ".config", "JetBrains");
}

export const INTELLIJ_CONFIG_BASE = intellijConfigPath();
